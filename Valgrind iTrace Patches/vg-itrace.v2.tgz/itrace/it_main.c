/*--------------------------------------------------------------------*/
/*--- itrace                                                       ---*/
/*---                                                    it_main.c ---*/
/*--------------------------------------------------------------------*/

/*
   This file is part of itrace, a Valgrind tool for instruction tracing.

   Authors: Dave Nomura (dcnomura@us.ibm.com) and Maynard Johnson
   (maynardj@us.ibm.com)
   (C) Copyright IBM Corporation 2006 - 2015

   This file is based on a similar file that is part of the callgrind tool,
   written by Josef Weidendorfer:
   Copyright (C) 2002-2006, Josef Weidendorfer (Josef.Weidendorfer@gmx.de)

   This program is free software; you can redistribute it and/or
   modify it under the terms of the GNU General Public License as
   published by the Free Software Foundation; either version 2 of the
   License, or (at your option) any later version.

   This program is distributed in the hope that it will be useful, but
   WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA
   02111-1307, USA.

   The GNU General Public License is contained in the file COPYING.
 */

#include "config.h"
#include "global.h"
#include "itrace.h"

#include <pub_tool_threadstate.h>
/*------------------------------------------------------------*/
/*--- Global variables                                     ---*/
/*------------------------------------------------------------*/

/* for all threads */
CommandLineOptions CLG_(clo);
Statistics CLG_(stat);
Bool CLG_(instrument_state) = True; /* Instrumentation on ? */

/* thread and signal handler specific */
exec_state CLG_(current_state);

Long total_insns_traced = 0;
Long num_func_insns_skipped = 0;
Long num_fn_calls = 0;
Long function_trigger_started = 1;

/*------------------------------------------------------------*/
/*--- Statistics                                           ---*/
/*------------------------------------------------------------*/

static void CLG_(init_statistics)(Statistics* s) {
	s->call_counter = 0;
	s->jcnd_counter = 0;
	s->jump_counter = 0;
	s->rec_call_counter = 0;
	s->ret_counter = 0;
	s->bb_executions = 0;

	s->context_counter = 0;
	s->bb_retranslations = 0;

	s->distinct_objs = 0;
	s->distinct_files = 0;
	s->distinct_fns = 0;
	s->distinct_contexts = 0;
	s->distinct_bbs = 0;
	s->distinct_bbccs = 0;
	s->distinct_instrs = 0;
	s->distinct_skips = 0;

	s->bb_hash_resizes = 0;
	s->bbcc_hash_resizes = 0;
	s->jcc_hash_resizes = 0;
	s->cxt_hash_resizes = 0;
	s->fn_array_resizes = 0;
	s->call_stack_resizes = 0;
	s->fn_stack_resizes = 0;

	s->full_debug_BBs = 0;
	s->file_line_debug_BBs = 0;
	s->fn_name_debug_BBs = 0;
	s->no_debug_BBs = 0;
	s->bbcc_lru_misses = 0;
	s->jcc_lru_misses = 0;
	s->cxt_lru_misses = 0;
	s->bbcc_clones = 0;
}

/* Initialise or check (if already seen before) an InstrInfo for next insn.
 We only can set instr_offset/instr_size here. The required event set and
 resulting cost offset depend on events (Ir/Dr/Dw/Dm) in guest
 instructions. The event set is extended as required on flush of the event
 queue (when Dm events were determined), cost offsets are determined at
 end of BB instrumentation. */
InstrInfo* next_InstrInfo(ClgState* clgs, UInt instr_size) {
   InstrInfo* ii;
   tl_assert(clgs->ii_index >= 0);
   tl_assert(clgs->ii_index < clgs->bb->instr_count);
   ii = &clgs->bb->instr[clgs->ii_index];

   if (clgs->seen_before) {
      CLG_ASSERT(ii->instr_offset == clgs->instr_offset);
      CLG_ASSERT(ii->instr_size == instr_size);
   } else {
      ii->instr_offset = clgs->instr_offset;
      ii->instr_size = instr_size;
      ii->eventset = 0;
   }

   clgs->ii_index++;
   clgs->instr_offset += instr_size;
   CLG_(stat).distinct_instrs++;

   return ii;
}

Addr IRConst2Addr(IRConst* con)
{
   Addr addr;

   if (sizeof(Addr) == 4) {
      CLG_ASSERT( con->tag == Ico_U32 );
      addr = con->Ico.U32;
   } else if (sizeof(Addr) == 8) {
      CLG_ASSERT( con->tag == Ico_U64 );
      addr = con->Ico.U64;
   } else
      VG_(tool_panic)("itrace: invalid Addr type");

   return addr;
}

Bool no_trace;
Bool increment_func_insns_skipped;
/* Do not trace since user has specified num-func-calls-before-start, but we've not
   yet reached that value.*/
BBCC* bbcc;
Addr bb_base;
thread_info* ti;

void after_bbsetup() {
   BB* bb;

   bbcc = CLG_(current_state).bbcc;
   bb = bbcc->bb;

   if (CLG_(clo).trace == Lk_TrxtAll)
      no_trace = False;
   else
      no_trace = (bbcc->cxt->fn[0]->trace == Lk_TrxtNone);

   bb_base = bb->obj->offset + bb->offset;
   ti = CLG_(get_current_thread)();
   /* Instructions may be missed.  */
   if (no_trace)
      ti->instrs_missed = True;
}


/* Dump instructions. */
/* First pass over a BB to instrument, counting instructions and jumps
 * This is needed for the size of the BB struct to allocate
 *
 * Called from CLG_(get_bb)
 */
void CLG_(collectBlockInfo)(IRSB* bbIn,
/*INOUT*/UInt* instrs,
/*INOUT*/UInt* cjmps,
/*INOUT*/Bool* cjmp_inverted) {
	Int i;
	IRStmt* st;
	Addr instrAddr = 0, jumpDst;
	UInt instrLen = 0;
	Bool toNextInstr = False;

	// Ist_Exit has to be ignored in preamble code, before first IMark:
	// preamble code is added by VEX for self modifying code, and has
	// nothing to do with client code
	Bool inPreamble = True;

	if (!bbIn)
		return;

	for (i = 0; i < bbIn->stmts_used; i++) {
		st = bbIn->stmts[i];
		if (Ist_IMark == st->tag) {
			inPreamble = False;

			instrAddr = (Addr) (st->Ist.IMark.addr);
			instrLen = st->Ist.IMark.len;

			(*instrs)++;
			toNextInstr = False;
		}
		if (inPreamble)
			continue;
		if (Ist_Exit == st->tag) {
			jumpDst = IRConst2Addr(st->Ist.Exit.dst);
			toNextInstr = (jumpDst == instrAddr + instrLen);

			(*cjmps)++;
		}
	}

	/* if the last instructions of BB conditionally jumps to next instruction
	 * (= first instruction of next BB in memory), this is a inverted by VEX.
	 */
	*cjmp_inverted = toNextInstr;
}


/* add helper call to setup_bbcc, with pointer to BB struct as argument
 *
 * precondition for setup_bbcc:
 * - jmps_passed has number of cond.jumps passed in last executed BB
 * - current_bbcc has a pointer to the BBCC of the last executed BB
 *   Thus, if bbcc_jmpkind is != -1 (JmpNone),
 *     current_bbcc->bb->jmp_addr
 *   gives the address of the jump source.
 *
 * the setup does 2 things:
 * - trace call:
 *   * Unwind own call stack, i.e sync our ESP with real ESP
 *     This is for ESP manipulation (longjmps, C++ exec handling) and RET
 *   * For CALLs or JMPs crossing objects, record call arg +
 *     push are on own call stack
 *
 * - prepare for cache log functions:
 *   set current_bbcc to BBCC that gets the costs for this BB execution
 *   attached
 */
void addBBSetupCall(ClgState* clgs) {
	IRDirty* di;
	IRExpr *arg1, **argv;

	arg1 = mkIRExpr_HWord((HWord) clgs->bb);
	argv = mkIRExprVec_1(arg1);
	di = unsafeIRDirty_0_N(1, "setup_bbcc", VG_(fnptr_to_fnentry)(
			&CLG_(setup_bbcc)), argv);
	addStmtToIRSB(clgs->sbOut, IRStmt_Dirty(di));
}

static IRSB* CLG_(instrument)(VgCallbackClosure* closure, IRSB* sbIn,
         const VexGuestLayout* layout, const VexGuestExtents* vge,
         const VexArchInfo* archinfo_host, IRType gWordTy, IRType hWordTy) {

   if (CLG_(clo).readable)
      return itrace_text_instrument(closure,  sbIn, layout, vge, gWordTy, hWordTy);
   else
      return itrace_binary_instrument(closure,  sbIn, layout, vge, gWordTy, hWordTy);
}

/*--------------------------------------------------------------------*/
/*--- Discarding BB info                                           ---*/
/*--------------------------------------------------------------------*/

// Called when a translation is removed from the translation cache for
// any reason at all: to free up space, because the guest code was
// unmapped or modified, or for any arbitrary reason.
static
void clg_discard_basic_block_info(Addr orig_addr64, VexGuestExtents vge) {
	Addr orig_addr = (Addr) orig_addr64;

	tl_assert(vge.n_used > 0);

	if (0)
		VG_(printf)("discard_basic_block_info: %p, %p, %llu\n",
				(void*) (Addr) orig_addr, (void*) (Addr) vge.base[0],
				(ULong) vge.len[0]);

	// Get BB info, remove from table, free BB info.  Simple!  Note that we
	// use orig_addr, not the first instruction address in vge.
	CLG_(delete_bb)(orig_addr);
}

/*------------------------------------------------------------*/
/*--- CLG_(fini)() and related function                     ---*/
/*------------------------------------------------------------*/
static
void unwind_thread(thread_info* t) {
	/* unwind signal handlers */
	while (CLG_(current_state).sig != 0)
		CLG_(post_signal)(CLG_(current_tid), CLG_(current_state).sig);

	/* unwind regular call stack */
	while (CLG_(current_call_stack).sp > 0)
		CLG_(pop_call_stack)();
}

/* Ups, this can go wrong... */
extern void VG_(discard_translations)(Addr start, ULong range);

void CLG_(set_instrument_state)(Char* reason, Bool state) {
	if (CLG_(instrument_state) == state) {
		CLG_DEBUG(2, "%s: instrumentation already %s\n",
				reason, state ? "ON" : "OFF");
		return;
	}
	CLG_(instrument_state) = state;
	CLG_DEBUG(2, "%s: Switching instrumentation %s ...\n",
			reason, state ? "ON" : "OFF");

	VG_(discard_translations)((Addr) 0x1000, (ULong) ~0xfffl);

	/* reset internal state: call stacks, simulator */
	CLG_(forall_threads)(unwind_thread);

	if (!state)
		CLG_(init_exec_state)(&CLG_(current_state));

	if (VG_(clo_verbosity) > 1)
		VG_(message)(Vg_DebugMsg, "%s: instrumentation switched %s\n",
				reason, state ? "ON" : "OFF");
}


static void CLG_(fini)(Int exitcode) {
   if (CLG_(clo).readable)
      _finish_text();
   else
      _finish_binary();
}

/*--------------------------------------------------------------------*/
/*--- Setup                                                        ---*/
/*--------------------------------------------------------------------*/
static void clg_start_client_code_callback(ThreadId tid, ULong blocks_done) {
	CLG_(run_thread)(tid);
}

static
void CLG_(post_clo_init)(void) {
   if (CLG_(clo).print_version)
      VG_(printf)("Valgrind-itrace version: %s\n", VG_ITRACE_VERSION);

   if ((VG_(strcmp)(CLG_(clo).fnname, (const HChar *)default_fnname) != 0) &&
            (CLG_(clo).trace == Lk_TrxtAll)) {
      VG_(printf)("The --trace-extent=all option is not compatible with the --fnname option\n");
      _print_usage();
      VG_(exit)(1);
   }
	VG_(clo_vex_control).iropt_unroll_thresh = 0;
	VG_(clo_vex_control).guest_chase_thresh = 0;

	CLG_DEBUG(1, "  dump threads: %s\n", CLG_(clo).separate_threads ? "Yes":"No");

	CLG_(init_eventsets)(0);
	CLG_(init_statistics)(&CLG_(stat));

	/* initialize hash tables */
	CLG_(init_obj_table)();
	CLG_(init_cxt_table)();
	CLG_(init_bb_hash)();

	CLG_(init_threads)();
	CLG_(run_thread)(1);

	CLG_(instrument_state) = True;
	if (CLG_(clo).readable)
	   _itrace_begin_text();
	else
	   _itrace_begin_binary();
}

static
void CLG_(pre_clo_init)(void) {

   VG_(details_name)("valgrind-itrace");
   VG_(details_version)(NULL);
   VG_(details_description)("Instruction and memory tracer.");
   VG_(details_copyright_author)("Copyright IBM (C) 2002-2016, and GNU GPL'd");
   VG_(details_bug_reports_to)(VG_BUGS_TO);
   VG_(details_avg_translation_sizeB)(245);

   VG_(basic_tool_funcs)(CLG_(post_clo_init), CLG_(instrument), CLG_(fini));

   VG_(needs_superblock_discards)(clg_discard_basic_block_info);

   VG_(needs_command_line_options)(CLG_(process_cmd_line_option),
            CLG_(print_usage), CLG_(print_debug_usage));

   VG_(track_start_client_code)(&clg_start_client_code_callback);
   VG_(track_pre_deliver_signal)(&CLG_(pre_signal));
   VG_(track_post_deliver_signal)(&CLG_(post_signal));

   CLG_(set_clo_defaults)();
}

void set_gap(void) {
   ti = CLG_(get_current_thread)();
   ti->instrs_missed = True;
}

IRAtom* get_Event_dea(Event* ev) {
   switch (ev->tag) {
      case Ev_Dr:
         return ev->Ev.Dr.ea;
      case Ev_Dw:
         return ev->Ev.Dw.ea;
      case Ev_Dm:
         return ev->Ev.Dm.ea;
      default:
         tl_assert(0);
   }
}

Int get_Event_dszB(Event* ev) {
   switch (ev->tag) {
      case Ev_Dr:
         return ev->Ev.Dr.szB;
      case Ev_Dw:
         return ev->Ev.Dw.szB;
      case Ev_Dm:
         return ev->Ev.Dm.szB;
      default:
         tl_assert(0);
   }
}

void showEvent(Event* ev) {
   switch (ev->tag) {
      case Ev_Ir:
         VG_(printf)("Ir (InstrInfo %p) at +%d\n", ev->inode,
                  ev->inode->instr_offset);
         break;
      case Ev_Dr:
         VG_(printf)("Dr (InstrInfo %p) at +%d %d EA=", ev->inode,
                  ev->inode->instr_offset, ev->Ev.Dr.szB);
         ppIRExpr(ev->Ev.Dr.ea);
         VG_(printf)("\n");
         break;
      case Ev_Dw:
         VG_(printf)("Dw (InstrInfo %p) at +%d %d EA=", ev->inode,
                  ev->inode->instr_offset, ev->Ev.Dw.szB);
         ppIRExpr(ev->Ev.Dw.ea);
         VG_(printf)("\n");
         break;
      case Ev_Dm:
         VG_(printf)("Dm (InstrInfo %p) at +%d %d EA=", ev->inode,
                  ev->inode->instr_offset, ev->Ev.Dm.szB);
         ppIRExpr(ev->Ev.Dm.ea);
         VG_(printf)("\n");
         break;
      case Ev_Bc:
         VG_(printf)("Bc %p   GA=", ev->inode);
         ppIRExpr(ev->Ev.Bc.taken);
         VG_(printf)("\n");
         break;
      case Ev_Bi:
         VG_(printf)("Bi %p  DST=", ev->inode);
         ppIRExpr(ev->Ev.Bi.dst);
         VG_(printf)("\n");
         break;
      case Ev_G:
         VG_(printf)("G  %p\n", ev->inode);
         break;
      default:
         tl_assert(0);
         break;
   }
}

static void init_Event(Event* ev) {
   VG_(memset)(ev, 0, sizeof(Event));
}

void addEvent_Ir(ClgState* clgs, InstrInfo* inode) {
   Event* evt;
   tl_assert(clgs->seen_before || (inode->eventset == 0));
   if (!CLG_(clo).trace_instrs)
      return;

   if (clgs->events_used == N_EVENTS) {
      if (CLG_(clo).readable)
         flushEvents_text_out(clgs);
      else
         flushEvents_binary_out(clgs);
   }
   tl_assert(clgs->events_used >= 0 && clgs->events_used < N_EVENTS);
   evt = &clgs->events[clgs->events_used];
   init_Event(evt);
   evt->is_entry = clgs->bb->is_entry;
   evt->tag = Ev_Ir;
   evt->inode = inode;
   clgs->events_used++;
}

void addEvent_Dr(ClgState* clgs, InstrInfo* inode, Int datasize, IRAtom* ea,
                 IREndness endian) {
   Event* evt;
   tl_assert(isIRAtom(ea));
   tl_assert(datasize >= 1 && datasize <= MIN_LINE_SIZE);
   if ((!CLG_(clo).trace_instrs) || (!CLG_(clo).trace_mem))
      return;

   if (clgs->events_used == N_EVENTS) {
      if (CLG_(clo).readable)
         flushEvents_text_out(clgs);
      else
         flushEvents_binary_out(clgs);
   }
   tl_assert(clgs->events_used >= 0 && clgs->events_used < N_EVENTS);
   evt = &clgs->events[clgs->events_used];
   init_Event(evt);
   evt->is_entry = clgs->bb->is_entry;
   evt->endian = endian;
   evt->tag = Ev_Dr;
   evt->inode = inode;
   evt->Ev.Dr.szB = datasize;
   evt->Ev.Dr.ea = ea;
   clgs->events_used++;
}

void addEvent_Dw(ClgState* clgs, InstrInfo* inode, Int datasize, IRAtom* ea,
                 IREndness endian) {
   Event* evt;
   tl_assert(isIRAtom(ea));
   tl_assert(datasize >= 1 && datasize <= MIN_LINE_SIZE);
   if ((!CLG_(clo).trace_instrs) || (!CLG_(clo).trace_mem))
      return;

   /* Is it possible to merge this write with the preceding read? */
   /* The QT format does not handle "M" (modify) type records, so we'll
    * skip this
   lastEvt = &clgs->events[clgs->events_used - 1];
   if (clgs->events_used > 0 && lastEvt->tag == Ev_Dr && lastEvt->Ev.Dr.szB
            == datasize && lastEvt->inode == inode && eqIRAtom(
                     lastEvt->Ev.Dr.ea, ea)) {
      lastEvt->tag = Ev_Dm;
      return;
   }
   */

   /* No.  Add as normal. */
   if (clgs->events_used == N_EVENTS) {
      if (CLG_(clo).readable)
         flushEvents_text_out(clgs);
      else
         flushEvents_binary_out(clgs);
   }
   tl_assert(clgs->events_used >= 0 && clgs->events_used < N_EVENTS);
   evt = &clgs->events[clgs->events_used];
   init_Event(evt);
   evt->endian = endian;
   evt->is_entry = clgs->bb->is_entry;
   evt->tag = Ev_Dw;
   evt->inode = inode;
   evt->Ev.Dw.szB = datasize;
   evt->Ev.Dw.ea = ea;
   clgs->events_used++;
}


VG_DETERMINE_INTERFACE_VERSION(CLG_(pre_clo_init))

/*--------------------------------------------------------------------*/
/*--- end                                                   main.c ---*/
/*--------------------------------------------------------------------*/
