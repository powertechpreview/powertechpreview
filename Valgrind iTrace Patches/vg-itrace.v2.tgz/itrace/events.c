/*--------------------------------------------------------------------*/
/*--- itrace                                                       ---*/
/*---                                                     events.c ---*/
/*--------------------------------------------------------------------*/

/*
   This file is part of itrace, a Valgrind tool for instruction tracing.

   Authors: Dave Nomura (dcnomura@us.ibm.com) and Maynard Johnson
            (maynardj@us.ibm.com)
   (C) Copyright IBM Corporation 2006 - 2015

   This file is based on a similar file that is part of the callgrind tool,
   written by Josef Weidendorfer:
   Copyright (C) 2002-2006, Josef Weidendorfer (Josef.Weidendorfer@gmx.de)

   This program is free software; you can redistribute it and/or
   modify it under the terms of the GNU General Public License as
   published by the Free Software Foundation; either version 2 of the
   License, or (at your option) any later version.

   This program is distributed in the hope that it will be useful, but
   WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA
   02111-1307, USA.

   The GNU General Public License is contained in the file COPYING.
*/

#include "global.h"

#define MAX_EVENTTYPE 10

static EventType eventtype[MAX_EVENTTYPE];
static Int eventtype_count = 0;

EventType* CLG_(register_eventtype)(const HChar* name)
{
  EventType* et;

  if (eventtype_count == MAX_EVENTTYPE) {
    VG_(printf)("\nMore than %d event types used!\n"
		"Increase MAX_EVENTTYPE in ct_events.c and recomile this tool!\n",
		MAX_EVENTTYPE);
    VG_(tool_panic)("Too many event types requested.");
  }

  et = &(eventtype[eventtype_count]);
  et->id = eventtype_count;
  et->name = VG_(strdup)("events.regevt", name);
  et->description = 0;

  eventtype_count++;

  return et;
}


EventType* CLG_(get_eventtype)(const HChar* name)
{
  Int i;

  for(i=0;i<eventtype_count;i++)
    if (VG_(strcmp)(eventtype[i].name, name) == 0)
      return eventtype+i;
  return 0;
}

EventType* CLG_(get_eventtype_byindex)(Int id)
{
  if ((id >= 0) && (id < eventtype_count))
    return eventtype+id;
  return 0;
}

/* Allocate space for an event set */
EventSet* CLG_(get_eventset)(const HChar* n, Int capacity)
{
  EventSet* es;

  es = (EventSet*) CLG_MALLOC("events.getevt", sizeof(EventSet) +
			       capacity * sizeof(EventSetEntry));
  es->capacity = capacity;
  es->size = 0;
  es->name = n;

  return es;
}

/* Incorporate a event type into a set, get start offset */
Int CLG_(add_eventtype)(EventSet* es, EventType* t)
{
  Int offset = es->size;
  if (es->capacity - offset < 1) return -1;

  es->size++;
  es->e[offset].type = t;
  es->e[offset].nextTop = es->size;

  return offset;
}

/* Incorporate one event set into another, get start offset */
Int CLG_(add_eventset)(EventSet* dst, EventSet* src)
{
  Int offset = dst->size, i;
  if (!src || (src->size == 0)) return offset;

  if (dst->capacity - offset < src->size) return -1;

  for(i=0;i<src->size;i++) {
    dst->e[offset+i].type = src->e[i].type;
    dst->e[offset+i].nextTop = src->e[i].nextTop + offset;
  }
  dst->size += src->size;

  return offset;
}

/* Incorporate two event types into a set, with second < first */
Int CLG_(add_dep_event2)(EventSet* es, EventType* e1, EventType* e2)
{
  Int offset = es->size;

  if (es->capacity - offset < 2) return -1;

  es->size += 2;
  es->e[offset].type = e1;
  es->e[offset].nextTop = es->size;
  es->e[offset+1].type = e2;
  es->e[offset+1].nextTop = es->size;

  return offset;
}

/* Incorporate 3 event types into a set, with third < second < first */
Int CLG_(add_dep_event3)(EventSet* es,
			EventType* e1, EventType* e2, EventType* e3)
{
  Int offset = es->size;

  if (es->capacity - offset < 3) return -1;

  es->size += 3;
  es->e[offset].type = e1;
  es->e[offset].nextTop = es->size;
  es->e[offset+1].type = e2;
  es->e[offset+1].nextTop = es->size;
  es->e[offset+2].type = e3;
  es->e[offset+2].nextTop = es->size;

  return offset;
}

Int CLG_(add_dep_event4)(EventSet* es,
			EventType* e1, EventType* e2,
			EventType* e3, EventType* e4)
{
  Int offset = es->size;

  if (es->capacity - offset < 4) return -1;

  es->size += 4;
  es->e[offset].type = e1;
  es->e[offset].nextTop = es->size;
  es->e[offset+1].type = e2;
  es->e[offset+1].nextTop = es->size;
  es->e[offset+2].type = e3;
  es->e[offset+2].nextTop = es->size;
  es->e[offset+3].type = e4;
  es->e[offset+3].nextTop = es->size;

  return offset;
}

/* Allocate space for an event mapping */
EventMapping* CLG_(get_eventmapping)(EventSet* es)
{
  EventMapping* em;

  CLG_ASSERT(es != 0);

  em = (EventMapping*) CLG_MALLOC("events.getevtmap", sizeof(EventMapping) +
				   es->capacity * sizeof(Int));
  em->capacity = es->capacity;
  em->size = 0;
  em->set = es;

  return em;
}

void CLG_(append_event)(EventMapping* em, const HChar* n)
{
  Int i;
  CLG_ASSERT(em != 0);

  for(i=0; i<em->set->size; i++)
    if (VG_(strcmp)(n, em->set->e[i].type->name)==0)
      break;

  if (i == em->set->size) return;

  CLG_ASSERT(em->capacity > em->size);

  em->index[em->size] = i;
  em->size++;
}

struct event_sets CLG_(sets);

/* Total reads/writes/misses sum over all dumps and threads.
 * Updated during CC traversal at dump time.
 */

EventMapping* CLG_(dumpmap) = 0;

void CLG_(init_eventsets)(Int max_user)
{
  EventSet *Ir, *Dr, *Dw;
  EventSet *full;

  EventType *e;

  Ir = CLG_(get_eventset)("Ir", 4);
  Dr = CLG_(get_eventset)("Dr", 4);
  Dw = CLG_(get_eventset)("Dw", 4);

  e = CLG_(register_eventtype)("Ir");
  CLG_(add_eventtype)(Ir, e);
  /*
  e = CLG_(register_eventtype)("Dr");
  CLG_(add_eventtype)(Dr, e);
  e = CLG_(register_eventtype)("Dw");
  CLG_(add_eventtype)(Dw, e);
  */

  full = CLG_(get_eventset)("full", Dr->size + Dw->size + Ir->size + max_user);

  CLG_(sets).off_full_Ir = CLG_(add_eventset)(full, Ir);
  CLG_(sets).off_full_Dr = CLG_(add_eventset)(full, Dr);
  CLG_(sets).off_full_Dw = CLG_(add_eventset)(full, Dw);

  CLG_DEBUGIF(1) {
    CLG_DEBUG(1, "EventSets:\n");
    CLG_(print_eventset)(-2, Ir);
    CLG_(print_eventset)(-2, Dr);
    CLG_(print_eventset)(-2, Dw);
    CLG_(print_eventset)(-2, full);
  }

  /* Not-existing events are silently ignored */
  CLG_(dumpmap) = CLG_(get_eventmapping)(full);
  CLG_(append_event)(CLG_(dumpmap), "Ir");
  CLG_(append_event)(CLG_(dumpmap), "Dr");
  CLG_(append_event)(CLG_(dumpmap), "Dw");
}
