/*--------------------------------------------------------------------*/
/*--- itrace                                                       ---*/
/*---                                                it_text_out.c ---*/
/*--------------------------------------------------------------------*/

/*
 This file is part of itrace, a Valgrind tool for instruction tracing.
 This files generates text-based output for instruction tracing and is
 only used when the "--readable=yes" option is passed.

 Author:  Maynard Johnson <maynardj@us.ibm.com>
 (C) Copyright IBM Corporation 2012 - 2015

 This program is free software; you can redistribute it and/or
 modify it under the terms of the GNU General Public License as
 published by the Free Software Foundation; either version 2 of the
 License, or (at your option) any later version.

 This program is distributed in the hope that it will be useful, but
 WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with this program; if not, write to the Free Software
 Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA
 02111-1307, USA.

 The GNU General Public License is contained in the file COPYING.
 */

#include "config.h"
#include "global.h"
#include "itrace.h"

#include <pub_tool_threadstate.h>

void _itrace_begin_text(void)
{
   VG_(printf)("H valgrind-itrace\n");
}

void _finish_text(void)
{
   return; // nothing to do
}

/*------------------------------------------------------------*/
/*--- Instruction trace instrumentation phase              ---*/
/*------------------------------------------------------------*/

static UChar print_buf[16];
static Bool skip_larx_stcx = False;
static const HChar *fnname_buf;

#define NEWLINE_LEN (VG_(strlen)("\n"))


static Bool _should_do_trace(Bool is_insn)
{
   static Bool skip_ldst = False;
   Bool skip_tracing = False;

   if (CLG_(clo).num_insns_to_trace &&
            total_insns_traced >= CLG_(clo).num_insns_to_trace) {
      VG_(printf)("Finished collecting specified total number of instructions %lld . . . Quitting.\n",
                 CLG_(clo).num_insns_to_trace);
      VG_(exit(0));
   }

   if (num_func_insns_skipped < CLG_(clo).num_insns_before_start)  {
      skip_tracing = True;
      if (increment_func_insns_skipped && is_insn)
         num_func_insns_skipped++;

      // If the last skipped instruction is a load or store, we want to
      // also skip the tracing of the 'W' or 'R' record.
      if (num_func_insns_skipped == CLG_(clo).num_insns_before_start)
         skip_ldst = True;
   } else if (skip_ldst) {
      skip_ldst = False;
      if (!is_insn)
         skip_tracing = True;
   } else {
      skip_ldst = False;
   }
   if (no_trace || skip_tracing) {
      ti = CLG_(get_current_thread)();
      ti->instrs_missed = True;
   }

   return !(no_trace | skip_tracing);
}

/* These are the instrumentation functions for printing instructions. */
static void print_data_le(Addr addr, HWord size) {
   Int j;

   VG_(memcpy)(print_buf, (UChar*) addr, size);
   for (j = size - 1; j >= 0; j--)
      if (print_buf[j] > 0xf)
         VG_(printf)("%2x", print_buf[j]);
      else
         VG_(printf)("0%x", print_buf[j]);
}
static void print_data_be(Addr addr, HWord size) {
   Int j;

   VG_(memcpy)(print_buf, (UChar*) addr, size);
   for (j = 0; j < size; j++)
      if (print_buf[j] > 0xf)
         VG_(printf)("%2x", print_buf[j]);
      else
         VG_(printf)("0%x", print_buf[j]);
}

#define MAKE_TRACE_LOAD(ENDIAN)                                            \
    static VG_REGPARM(2) void trace_load_##ENDIAN(Addr addr, HWord size)   \
    {                                                                      \
  if (!_should_do_trace(False)) return;                                    \
  total_insns_traced++;                                                    \
  VG_(printf)("R ");                                                       \
  VG_(printf)("%p ", (void *)addr);                                        \
  print_data_##ENDIAN (addr, size);                                        \
  VG_(printf)("\n");                                                       \
    }

#define MAKE_TRACE_STORE(ENDIAN)                                           \
    static VG_REGPARM(2) void trace_store_##ENDIAN(Addr addr, HWord size)  \
    {                                                                      \
  if (!_should_do_trace(False)) return;                                    \
  total_insns_traced++;                                                    \
  VG_(printf)("W ");                                                       \
  VG_(printf)("%p ", (void *)addr);                                        \
  print_data_##ENDIAN (addr, size);                                        \
  VG_(printf)("\n");                                                       \
    }
#define MAKE_TRACE_MODIFY(ENDIAN)                                          \
    static VG_REGPARM(2) void trace_modify_##ENDIAN(Addr addr, SizeT size) \
    {                                                                      \
  if (!_should_do_trace(False)) return;                                    \
  total_insns_traced++;                                                    \
  VG_(printf)("M ");                                                       \
  VG_(printf)("%p ", (void *)addr);                                        \
  print_data_##ENDIAN (addr, size);                                        \
  VG_(printf)("\n");                                                       \
    }


MAKE_TRACE_LOAD(be)
MAKE_TRACE_LOAD(le)
MAKE_TRACE_STORE(le)
MAKE_TRACE_STORE(be)
MAKE_TRACE_MODIFY(be)
MAKE_TRACE_MODIFY(le)

#define ITRACE_LLSC_SIZE 1024
#define ITRACE_MAX_TRACE_LINE_LEN 128
static Int num_trace_lines;

static Int buffer_bumps;
// This buffer is used only when we've detected a larx/stcx sequence.
static Char (*trace_data)[ITRACE_MAX_TRACE_LINE_LEN] = NULL;

static inline
void addStringToTrcData(Char * trcdata, const HChar * str) {
   CLG_ASSERT((VG_(strlen)((const HChar *)trcdata) + VG_(strlen)((const HChar *)str)) < ITRACE_MAX_TRACE_LINE_LEN);
   VG_(strncat)((HChar *)trcdata, (const HChar *)str, ITRACE_MAX_TRACE_LINE_LEN);
}

static inline
void addLineToTraceBuffer(Char * line)
{
   if (!(num_trace_lines % ITRACE_LLSC_SIZE)) {
      buffer_bumps++;
      trace_data = (Char (*)[])CLG_REALLOC("itrace.addLine2buf.1",
                                           trace_data, ITRACE_LLSC_SIZE * buffer_bumps * sizeof *trace_data);
   }
   VG_(strncpy)((HChar *)trace_data[num_trace_lines - 1], (HChar *)line, ITRACE_MAX_TRACE_LINE_LEN);
}

/* These are the instrumentation functions for buffering instructions to
 * be printed later (avoiding printing during larx/stcx).
 */
#define SPACE_LEFT(x)   ((ITRACE_MAX_TRACE_LINE_LEN) - (VG_(strlen)((HChar *)x)))
static void buffer_data_le(Addr addr, HWord size, Char * trcline) {
   Int j;
   Char * line = trcline;
   VG_(memcpy)(print_buf, (UChar*) addr, size);
   trcline += VG_(strlen)((HChar *)trcline);
   for (j = size - 1; j >= 0; j--) {
      if (print_buf[j] > 0xf)
         VG_(snprintf)((HChar *)trcline, SPACE_LEFT(line), "%2x", print_buf[j]);
      else
         VG_(snprintf)((HChar *)trcline, SPACE_LEFT(line), "0%x", print_buf[j]);
      trcline += VG_(strlen)((HChar *)trcline);
   }
}
static void buffer_data_be(Addr addr, HWord size, Char * trcline) {
   Int j;
   Char * line = trcline;
   VG_(memcpy)(print_buf, (UChar*) addr, size);
   trcline += VG_(strlen)((HChar *)trcline);
   for (j = 0; j < size; j++) {
      if (print_buf[j] > 0xf)
         VG_(snprintf)((HChar *)trcline, SPACE_LEFT(line), "%2x", print_buf[j]);
      else
         VG_(snprintf)((HChar *)trcline, SPACE_LEFT(line), "0%x", print_buf[j]);
      trcline += VG_(strlen)((HChar *)trcline);
   }
}

#define MAKE_BUFFER_LOAD(ENDIAN)                                              \
    static VG_REGPARM(2) void buffer_load_##ENDIAN(Addr addr, HWord size)     \
    {                                                                         \
  if (!_should_do_trace(False)) return;                                       \
  Char line[ITRACE_MAX_TRACE_LINE_LEN];                                       \
  Char * curr_line = line;                                                    \
  total_insns_traced++;                                                       \
  curr_line[0] = '\0';                                                        \
  VG_(strncat)((HChar *)curr_line, "R ", SPACE_LEFT(line));                   \
  curr_line += VG_(strlen)((HChar *)curr_line);                               \
  VG_(snprintf)((HChar *)curr_line, SPACE_LEFT(line), "%p ", (void *)addr);   \
  curr_line += VG_(strlen)((HChar *)curr_line);                               \
  buffer_data_##ENDIAN (addr, size, line);                                    \
  VG_(strncat)((HChar *)curr_line, "\n", SPACE_LEFT(line));                   \
  ++num_trace_lines;                                                          \
  addLineToTraceBuffer(line);                                                 \
    }

#define MAKE_BUFFER_STORE(ENDIAN)                                             \
    static VG_REGPARM(2) void buffer_store_##ENDIAN(Addr addr, HWord size)    \
    {                                                                         \
  if (!_should_do_trace(False)) return;                                       \
  Char line[ITRACE_MAX_TRACE_LINE_LEN];                                       \
  Char * curr_line = line;                                                    \
  total_insns_traced++;                                                       \
  curr_line[0] = '\0';                                                        \
  VG_(strncat)((HChar *)curr_line, "W ", SPACE_LEFT(line));                   \
  curr_line += VG_(strlen)((HChar *)curr_line);                               \
  VG_(snprintf)((HChar *)curr_line, SPACE_LEFT(line), "%p ", (void *)addr);   \
  curr_line += VG_(strlen)((HChar *)curr_line);                               \
  buffer_data_##ENDIAN (addr, size, line);                                    \
  VG_(strncat)((HChar *)curr_line, "\n", SPACE_LEFT(line));                   \
  ++num_trace_lines;                                                          \
  addLineToTraceBuffer(line);                                                 \
    }
/*  ppc64 does not have a "modify instruction.
#define MAKE_BUFFER_MODIFY(ENDIAN)                                            \
static VG_REGPARM(2) void buffer_modify_##ENDIAN(Addr addr, SizeT size)       \
                {                                                             \
        if (no_trace) return;                                                 \
        Char line[ITRACE_MAX_TRACE_LINE_LEN];                                 \
        Char * curr_line = line;                                              \
        curr_line[0] = '\0';                                                  \
        VG_(strncat)(curr_line, "M ", SPACE_LEFT(line));                      \
        curr_line += VG_(strlen)(curr_line);                                  \
        VG_(snprintf)(curr_line, SPACE_LEFT(line), "%p ", (void *)addr);      \
        curr_line += VG_(strlen)(curr_line);                                  \
        buffer_data_##ENDIAN (addr, size, line);                              \
        VG_(strncat)(curr_line, "\n", SPACE_LEFT(line));                      \
                }
 */

MAKE_BUFFER_LOAD(be)
MAKE_BUFFER_LOAD(le)
MAKE_BUFFER_STORE(le)
MAKE_BUFFER_STORE(be)
/*  ppc64 does not have a "modify instruction.
MAKE_BUFFER_MODIFY(be)
MAKE_BUFFER_MODIFY(le)
 */

static void __buffer_instruction(InstrInfo* ii, Char * trcdata) {
   int i;
   UChar * b;
   Addr addr;
   Char line[ITRACE_MAX_TRACE_LINE_LEN];
   Char * curr_line = line;

   CLG_ASSERT(ii->instr_size <= VG_MAX_INSTR_SZB);

   /* If instructions have been missed tracing in this thread, print "G". */
   if (ti->instrs_missed) {
      ti->instrs_missed = False;
      addStringToTrcData(trcdata, "G\n");
   }

   addr = bb_base + ii->instr_offset;

   /* Print instruction address if it is the first one in this block.  */
   curr_line[0] = '\0';
   if (ii->instr_offset == 0)
      VG_(snprintf)((HChar *)curr_line, SPACE_LEFT(line), "J %p ",
               (void *) addr);
   else {
      VG_(strncat)((HChar *)curr_line, "I ", SPACE_LEFT(line));
   }

   /* extract instruction.  */
   curr_line = line + VG_(strlen)((HChar *)line);
   b = (UChar*) addr;
   for (i = 0; i < ii->instr_size; i++) {
      if (b[i] > 0xf)
         VG_(snprintf)((HChar *)curr_line, SPACE_LEFT(line), "%2x", b[i]);
      else
         VG_(snprintf)((HChar *)curr_line, SPACE_LEFT(line), "0%x", b[i]);
      curr_line += VG_(strlen)((HChar *)curr_line);
   }

   curr_line = line + VG_(strlen)((HChar *)line);
   addStringToTrcData(trcdata, (HChar *)line);
}

static VG_REGPARM(1)
void buffer_instruction(InstrInfo* ii)
{
   Char trcdata[ITRACE_MAX_TRACE_LINE_LEN];
   Char fname_str[ITRACE_MAX_TRACE_LINE_LEN];
   Bool func_entry;

   if (!_should_do_trace(True))
      return;

   total_insns_traced++;

   trcdata[0] = '\0';
   __buffer_instruction(ii, trcdata);

   func_entry =  VG_(get_fnname_if_entry(bb_base + ii->instr_offset,
                                         &fnname_buf));
#if _CALL_ELF == 2
   /*
    * The Elf V2 for ppc64 (used when in little endian mode) employs both local
    * and global toc pointers. When a local function call is made, gcc is smart
    * enough to know it can skip the toc setup at the beginning of the function
    * since the local toc is guaranteed to already be setup for the compilation
    * unit where the call is made.  Thus, bb_base may be two instructions past
    * the beginning of the function.  Note:  Under certain conditions, the offset
    * from the beginning of the function may be other than two instructions,
    * but to determine this for certain would require inspecting the ELF info
    * for the binary file (which is not feasible here).  For the purpose at hand,
    * the function name obtained from get_fnname_if_entry is just used as a
    * comment in the text format of the itrace output anyway.
    */
   if (!ii->instr_offset && !func_entry)
      func_entry = VG_(get_fnname_if_entry(bb_base - 8,
                                           &fnname_buf));
#endif

   if (func_entry) {
      VG_(snprintf)((HChar *)fname_str, VG_(strlen)(fnname_buf)+4, " ;%s", fnname_buf);
      addStringToTrcData(trcdata, (HChar *)fname_str);
   }

   addStringToTrcData(trcdata, "\n");
   ++num_trace_lines;
   addLineToTraceBuffer(trcdata);
}

static VG_REGPARM(0)
void print_tracelines(void)
{
   Int i;
   for (i = 0; i < num_trace_lines; i++) {
      VG_(printf)("%p",(HChar *)trace_data[i]);
   }
   num_trace_lines = 0;

   /* This would seem to be the right place to put a CLG_FREE of
    * the malloc'ed trace buffer, but things go to hell in a hand-basket
    * if I execute the following two instructions.  It's probably better
    * for performance to not free the buffer, because I'd just have to
    * recreate it the next time I encounter a block that has larx/stcx.
    */
   //CLG_FREE(trace_data);
   //trace_data = NULL;
}

static void addWrTmp_lxstx(IRSB * sbOut, Int datasize, IRAtom* ea,
                           IREndness endian)
{
   if ((!CLG_(clo).trace_instrs) || (!CLG_(clo).trace_mem))
      return;
   const HChar * helperFunc;
   void * helperAddr;
   IRExpr * arg1 = ea;
   IRExpr * arg2 = mkIRExpr_HWord(datasize);
   if (endian == Iend_BE) {
      helperFunc = "buffer_load_be";
      helperAddr = buffer_load_be;
   } else {
      helperFunc = "buffer_load_le";
      helperAddr = buffer_load_le;
   }
   {
      IRExpr ** argv = mkIRExprVec_2(arg1, arg2);
      IRDirty * di = unsafeIRDirty_0_N(2, helperFunc, VG_(fnptr_to_fnentry)(
               helperAddr), argv);
      addStmtToIRSB(sbOut, IRStmt_Dirty(di));
   }

}

static void addStore_lxstx(IRSB * sbOut, Int datasize, IRAtom* ea,
                           IREndness endian)
{
   if ((!CLG_(clo).trace_instrs) || (!CLG_(clo).trace_mem))
      return;
   const HChar * helperFunc;
   void * helperAddr;
   IRExpr * arg1 = ea;
   IRExpr * arg2 = mkIRExpr_HWord(datasize);
   if (endian == Iend_BE) {
      helperFunc = "buffer_store_be";
      helperAddr = buffer_store_be;
   } else {
      helperFunc = "buffer_store_le";
      helperAddr = buffer_store_le;
   }
   {
      IRExpr ** argv = mkIRExprVec_2(arg1, arg2);
      IRDirty * di = unsafeIRDirty_0_N(2, helperFunc, VG_(fnptr_to_fnentry)(
               helperAddr), argv);
      addStmtToIRSB(sbOut, IRStmt_Dirty(di));
   }
}

static void addIMark_lxstx(IRSB * sbOut, InstrInfo* inode)
{
   if (!CLG_(clo).trace_instrs)
      return;
   const HChar * helperFunc = "buffer_instruction";
   void * helperAddr = buffer_instruction;
   IRExpr * arg1 = mkIRExpr_HWord((HWord) inode);
   IRExpr ** argv = mkIRExprVec_1(arg1);
   IRDirty * di = unsafeIRDirty_0_N(1, helperFunc, VG_(fnptr_to_fnentry)(
            helperAddr), argv);
   addStmtToIRSB(sbOut, IRStmt_Dirty(di));
}

static void __print_instruction(InstrInfo* ii) {
   UInt * b;
   Addr addr;

   CLG_ASSERT(ii->instr_size <= VG_MAX_INSTR_SZB);

   /* If instructions have been missed tracing in this thread, print "G". */
   if (ti->instrs_missed) {
      ti->instrs_missed = False;
      VG_(printf)("G\n");
   }

   addr = bb_base + ii->instr_offset;
   /* Print instruction address if it is the first one in this block.  */
   if (ii->instr_offset == 0)
      VG_(printf)("J %p ", (void *) addr);
   else {
      VG_(printf)("I ");
   }

   /* Print instruction.  */
   b = (UInt *) addr;
   VG_(printf)("%8x", *b);
}

static VG_REGPARM(1)
void print_instruction(InstrInfo* ii)
{
   Bool func_entry;

   if (!_should_do_trace(True))
      return;

   total_insns_traced++;

   __print_instruction(ii);


   func_entry = VG_(get_fnname_if_entry(bb_base + ii->instr_offset,
                                        &fnname_buf));
#if _CALL_ELF == 2
   /*
    * The Elf V2 for ppc64 (used when in little endian mode) employs both local
    * and global toc pointers. When a local function call is made, gcc is smart
    * enough to know it can skip the toc setup at the beginning of the function
    * since the local toc is guaranteed to already be setup for the compilation
    * unit where the call is made.  Thus, bb_base may be two instructions past
    * the beginning of the function.  Note:  Under certain conditions, the offset
    * from the beginning of the function may be other than two instructions,
    * but to determine this for certain would require inspecting the ELF info
    * for the binary file (which is not feasible here).  For the purpose at hand,
    * the function name obtained from get_fnname_if_entry is just used as a
    * comment in the text format of the itrace output anyway.
    */
   if (!ii->instr_offset && !func_entry)
      func_entry = VG_(get_fnname_if_entry(bb_base - 8,
                                           &fnname_buf));
#endif

   if (func_entry)
      VG_(printf)(" ;%s\n", fnname_buf);
   else
      VG_(printf)("\n");
}


/* Generate code for all outstanding events, and mark the queue
 empty.  Code is generated into cgs->sbOut, and this activity
 'consumes' slots in cgs->bb.
 */
void flushEvents_text_out(ClgState* clgs) {
   Int i, argc;
   const HChar* helperName;
   void* helperAddr;
   IRExpr *arg1 = 0, *arg2 = 0, **argv = 0;
   IRDirty* di;
   Event* ev;

   for (i = 0; i < clgs->events_used; i++) {
      /* generate IR to notify event i */
      tl_assert(i >= 0 && i < clgs->events_used);

      ev = &clgs->events[i];
      helperName = NULL;
      helperAddr = NULL;
      argv = NULL;

      CLG_DEBUGIF(5) {
         VG_(printf)("   flush ");
         showEvent(ev);
      }

      // Decide on helper fn to call and args to pass it.
      switch (ev->tag) {
         case Ev_Ir:
            helperName = "print_instruction";
            helperAddr = print_instruction;
            argc = 1;
            arg1 = mkIRExpr_HWord((HWord) ev->inode);
            break;
         case Ev_Dr:
            argc = 2;
            arg1 = get_Event_dea(ev);
            arg2 = mkIRExpr_HWord(get_Event_dszB(ev));
            if (ev->endian == Iend_BE) {
               helperName = "trace_load_be";
               helperAddr = trace_load_be;
            } else {
               helperName = "trace_load_le";
               helperAddr = trace_load_le;
            }
            break;
         case Ev_Dw:
            argc = 2;
            arg1 = get_Event_dea(ev);
            arg2 = mkIRExpr_HWord(get_Event_dszB(ev));
            if (ev->endian == Iend_BE) {
               helperName = "trace_store_be";
               helperAddr = trace_store_be;
            } else {
               helperName = "trace_store_le";
               helperAddr = trace_store_le;
            }
            break;
         case Ev_Dm:
            argc = 2;
            arg1 = get_Event_dea(ev);
            arg2 = mkIRExpr_HWord(get_Event_dszB(ev));
            if (ev->endian == Iend_BE) {
               helperName = "trace_modify_be";
               helperAddr = trace_modify_be;
            } else {
               helperName = "trace_modify_le";
               helperAddr = trace_modify_le;
            }
            break;
         default:
            tl_assert(0);
      }

      // Add the helper.
      // Add call to the instrumentation function
      if (argc == 1)
         argv = mkIRExprVec_1(arg1);
      else if (argc == 2)
         argv = mkIRExprVec_2(arg1, arg2);
      di = unsafeIRDirty_0_N( /*regparms*/argc, helperName,
                              VG_(fnptr_to_fnentry)(helperAddr), argv);
      addStmtToIRSB(clgs->sbOut, IRStmt_Dirty(di));
   }
   clgs->events_used = 0;
}


//static Char instr_buf[2 + VG_MAX_INSTR_SZB * 2];
//static Char * fnname_buf;

inline static Int sb_has_LLSC(Int i, IRSB* sbIn) {
   IRStmt* st;
   for (; i < sbIn->stmts_used; i++) {
      st = sbIn->stmts[i];
      if (st->tag == Ist_LLSC)
         return i;
   }
   return -1;
}

typedef enum {
   LXSTX_NONE,
   LXSTX_LOAD_STAGE,
   LXSTX_STORE_STAGE
} lxstx_stage;
static lxstx_stage larx_stcx_stage = LXSTX_NONE;


IRSB* itrace_text_instrument(VgCallbackClosure* closure, IRSB* sbIn,
                             const VexGuestLayout* layout,
                             const VexGuestExtents* vge, IRType gWordTy,
                             IRType hWordTy) {
   Int i, isize, indx_of_LLSC;
   IRStmt* st;
   Addr origAddr;
   Addr cia; /* address of current insn */
   InstrInfo* curr_inode = NULL;
   ClgState clgs;
   UInt cJumps = 0;
   IREndness endian;

   if (gWordTy != hWordTy) {
      /* We don't currently support this case. */
      VG_(tool_panic)("host/guest word size mismatch");
   }

   // No instrumentation if it is switched off
   if (!CLG_(instrument_state)) {
      CLG_DEBUG(5, "instrument(BB 0x%llx) [Instrumentation OFF]\n",
                (unsigned long long)closure->readdr);
      return sbIn;
   }

   CLG_DEBUG(3, "+ instrument(BB  0x%llx)\n", (unsigned long long)closure->readdr);

   /* Set up SB for instrumented IR */
   clgs.sbOut = deepCopyIRSBExceptStmts(sbIn);

   // Copy verbatim any IR preamble preceding the first IMark
   i = 0;
   while (i < sbIn->stmts_used && sbIn->stmts[i]->tag != Ist_IMark) {
      addStmtToIRSB(clgs.sbOut, sbIn->stmts[i]);
      i++;
   }

   // Get the first statement, and origAddr from it
   CLG_ASSERT(sbIn->stmts_used >0);
   CLG_ASSERT(i < sbIn->stmts_used);
   st = sbIn->stmts[i];
   CLG_ASSERT(Ist_IMark == st->tag);

   origAddr = (Addr) st->Ist.IMark.addr;
   cia = st->Ist.IMark.addr;
   isize = st->Ist.IMark.len;
   CLG_ASSERT(origAddr == st->Ist.IMark.addr); // XXX: check no overflow

   /* Get BB struct (creating if necessary).
    * JS: The hash table is keyed with orig_addr_noredir -- important!
    * JW: Why? If it is because of different chasing of the redirection,
    *     this is not needed, as chasing is switched off in itrace
    */
   clgs.bb = CLG_(get_bb)(origAddr, sbIn, &(clgs.seen_before));

   addBBSetupCall(&clgs);

   // Set up running state
   clgs.events_used = 0;
   clgs.ii_index = 0;
   clgs.instr_offset = 0;

   /* Scan ahead to see if any larx/stcx instructions are in this super block.
    * If so, enable special handling around them. */
   if ((indx_of_LLSC = sb_has_LLSC(i, sbIn)) >= 0) {
      skip_larx_stcx = True;
      if (trace_data == NULL) {
         buffer_bumps = 1;
         trace_data = (Char (*)[])CLG_MALLOC("itrace.instrument.1",
                                             ITRACE_LLSC_SIZE * buffer_bumps * sizeof *trace_data);
      }

      if (larx_stcx_stage == LXSTX_NONE)
         larx_stcx_stage = LXSTX_LOAD_STAGE;
   }

   for (/*use current i*/; i < sbIn->stmts_used; i++) {
      if ((skip_larx_stcx == True) && (larx_stcx_stage == LXSTX_STORE_STAGE)) {
         /* We've just finished skipping over a larx/stcx sequence,
          * but haven't printed out the stored trace data yet.
          * So add an instrumentation statement to the IRSB to
          * print the trace array that we've collected.  Set flags
          * so we return to normal processing.
          */
         IRDirty * di;
         IRExpr ** argv_lxstx = mkIRExprVec_0();
         skip_larx_stcx = False;
         larx_stcx_stage = LXSTX_NONE;

         di = unsafeIRDirty_0_N(0, "print_tracelines", VG_(fnptr_to_fnentry)(
                  print_tracelines), argv_lxstx);
         addStmtToIRSB(clgs.sbOut, IRStmt_Dirty(di));
      }

      st = sbIn->stmts[i];
      CLG_ASSERT(isFlatIRStmt(st));

      switch (st->tag) {
         case Ist_NoOp:
         case Ist_AbiHint:
         case Ist_Put:
         case Ist_PutI:
         case Ist_MBE:
            break;

         case Ist_IMark: {
            cia = st->Ist.IMark.addr;
            isize = st->Ist.IMark.len;
            CLG_ASSERT(clgs.instr_offset == (Addr)cia - origAddr);
            // If Vex fails to decode an instruction, the size will be zero.
            // Pretend otherwise.
            if (isize == 0)
               isize = VG_MIN_INSTR_SZB;

            // Sanity-check size.
            tl_assert( (VG_MIN_INSTR_SZB <= isize && isize <= VG_MAX_INSTR_SZB)
                       || VG_CLREQ_SZB == isize );

            // Init the inode, record it as the current one.
            // Subsequent Dr/Dw/Dm events from the same instruction will
            // also use it.
            curr_inode = next_InstrInfo(&clgs, isize);

            if (skip_larx_stcx)
               addIMark_lxstx(clgs.sbOut, curr_inode);
            else
               addEvent_Ir(&clgs, curr_inode);
            break;
         }

         case Ist_WrTmp: {
            IRExpr* data = st->Ist.WrTmp.data;
            if (data->tag == Iex_Load) {
               IRExpr* aexpr = data->Iex.Load.addr;
               endian = data->Iex.Load.end;
               if (skip_larx_stcx)
                  addWrTmp_lxstx(clgs.sbOut, sizeofIRType(data->Iex.Load.ty),
                                 aexpr, endian);
               else
                  addEvent_Dr(&clgs, curr_inode, sizeofIRType(data->Iex.Load.ty),
                              aexpr, endian);
            }
            break;
         }

         case Ist_Store: {
            IRExpr* data = st->Ist.Store.data;
            IRExpr* aexpr = st->Ist.Store.addr;
            endian = st->Ist.Store.end;

            if (skip_larx_stcx)
               addStore_lxstx(clgs.sbOut, sizeofIRType(typeOfIRExpr(
                        sbIn->tyenv, data)),
                        aexpr, endian);
            else
               addEvent_Dw(&clgs, curr_inode, sizeofIRType(typeOfIRExpr(
                        sbIn->tyenv, data)), aexpr, endian);
            break;
         }

         case Ist_Dirty: {
            Int dataSize;
            IRDirty* d = st->Ist.Dirty.details;
            if (d->mFx != Ifx_None) {
               /* This dirty helper accesses memory.  Collect the details. */
               tl_assert(d->mAddr != NULL);
               tl_assert(d->mSize != 0);
               dataSize = d->mSize;
               // Large (eg. 28B, 108B, 512B on x86) data-sized
                        // instructions will be done inaccurately, but they're
                        // very rare and this avoids errors from hitting more
                        // than two cache lines in the simulation.
               /*  FIXME: I am not sure how to get the endian from Ist_Dirty.  */
               endian = Iend_BE;
               if (dataSize > MIN_LINE_SIZE)
                  dataSize = MIN_LINE_SIZE;
               if (d->mFx == Ifx_Read || d->mFx == Ifx_Modify)
                  addEvent_Dr(&clgs, curr_inode, dataSize, d->mAddr, endian);
               if (d->mFx == Ifx_Write || d->mFx == Ifx_Modify)
                  addEvent_Dw(&clgs, curr_inode, dataSize, d->mAddr, endian);
            } else {
               tl_assert(d->mAddr == NULL);
               tl_assert(d->mSize == 0);
            }
            break;
         }

         case Ist_LLSC: {
            IRType dataTy;
            endian = st->Ist.LLSC.end;
            IRExpr* aexpr = st->Ist.LLSC.addr;

            if (st->Ist.LLSC.storedata == NULL) {
               /* LL */
               dataTy = typeOfIRTemp(sbIn->tyenv, st->Ist.LLSC.result);
               addWrTmp_lxstx(clgs.sbOut, sizeofIRType(dataTy),
                              aexpr, endian);
            } else {
               /* SC */
               larx_stcx_stage = LXSTX_STORE_STAGE;
               dataTy = typeOfIRExpr(sbIn->tyenv, st->Ist.LLSC.storedata);
               addStore_lxstx(clgs.sbOut, sizeofIRType(dataTy),
                              aexpr, endian);
            }
            break;
         }

         case Ist_Exit: {
            Bool guest_exit, inverted;

            /* VEX code generation sometimes inverts conditional branches.
             * As Callgrind counts (conditional) jumps, it has to correct
             * inversions. The heuristic is the following:
             * (1) Callgrind switches off SB chasing and unrolling, and
             *     therefore it assumes that a candidate for inversion only is
             *     the last conditional branch in an SB.
             * (2) inversion is assumed if the branch jumps to the address of
             *     the next guest instruction in memory.
             * This heuristic is precalculated in CLG_(collectBlockInfo)().
             *
             * Branching behavior is also used for branch prediction. Note that
             * above heuristic is different from what Cachegrind does.
             * Cachegrind uses (2) for all branches.
             */
            if (cJumps + 1 == clgs.bb->cjmp_count)
               inverted = clgs.bb->cjmp_inverted;
            else
               inverted = False;

            // call branch predictor only if this is a branch in guest code
            guest_exit = (st->Ist.Exit.jk == Ijk_Boring) ||
                         (st->Ist.Exit.jk == Ijk_Call) ||
                         (st->Ist.Exit.jk == Ijk_Ret);

            if (guest_exit) {
               /* Stuff to widen the guard expression to a host word, so
                                 we can pass it to the branch predictor simulation
                                 functions easily. */
               IRType tyW = hWordTy;
               IROp widen = tyW == Ity_I32 ? Iop_1Uto32 : Iop_1Uto64;
               IROp opXOR = tyW == Ity_I32 ? Iop_Xor32 : Iop_Xor64;
               IRTemp guard1 = newIRTemp(clgs.sbOut->tyenv, Ity_I1);
               IRTemp guardW = newIRTemp(clgs.sbOut->tyenv, tyW);
               IRTemp guard = newIRTemp(clgs.sbOut->tyenv, tyW);
               IRExpr* one = tyW == Ity_I32 ? IRExpr_Const(IRConst_U32(1))
                                            : IRExpr_Const(IRConst_U64(1));

               /* Widen the guard expression. */
               addStmtToIRSB(clgs.sbOut, IRStmt_WrTmp(guard1,
                                                      st->Ist.Exit.guard));
               addStmtToIRSB(clgs.sbOut, IRStmt_WrTmp(guardW, IRExpr_Unop(
                        widen, IRExpr_RdTmp(guard1))));
               /* If the exit is inverted, invert the sense of the guard. */
               addStmtToIRSB(clgs.sbOut, IRStmt_WrTmp(guard,
                                                      inverted ? IRExpr_Binop(opXOR, IRExpr_RdTmp(guardW),
                                                                              one) : IRExpr_RdTmp(guardW)));
               /* No need for "branch" event since itrace inserts no simulation. */
            }

            /* We may never reach the next statement, so need to flush
             * all outstanding transactions now.  But only do this for normal flow.
             */
            if (skip_larx_stcx == False)
               flushEvents_text_out(&clgs);

            CLG_ASSERT(clgs.ii_index>0);
            if (!clgs.seen_before) {
              ClgJumpKind jk;

              if (st->Ist.Exit.jk == Ijk_Call)
                 jk = jk_Call;
              else if (st->Ist.Exit.jk == Ijk_Ret)
                 jk = jk_Return;
              else {
                 if (IRConst2Addr(st->Ist.Exit.dst) ==
                          origAddr + curr_inode->instr_offset + curr_inode->instr_size)
                    jk = jk_None;
                 else
                    jk = jk_Jump;
              }

              clgs.bb->jmp[cJumps].instr = clgs.ii_index-1;
              clgs.bb->jmp[cJumps].jmpkind = jk;
            }

            /* Update global variable jmps_passed before the jump
             * A correction is needed if VEX inverted the last jump condition
             */
            addConstMemStoreStmt(clgs.sbOut,
                                 (UWord) &CLG_(current_state).jmps_passed, inverted ? cJumps
                                                                                    + 1 : cJumps, hWordTy);
            cJumps++;
            break;
         }

         default:
            tl_assert(0);
            break;
      }
      /* Copy the original statement */
      addStmtToIRSB(clgs.sbOut, st);

      CLG_DEBUGIF(5) {
         VG_(printf)("   pass  ");
         ppIRStmt(st);
         VG_(printf)("\n");
      }
   }

   /* At the end of the bb.  Flush outstandings. */
   flushEvents_text_out(&clgs);

   /* Always update global variable jmps_passed at end of bb.
    * A correction is needed if VEX inverted the last jump condition
    */
   {
      UInt jmps_passed = cJumps;
      if (clgs.bb->cjmp_inverted)
         jmps_passed--;
      addConstMemStoreStmt(clgs.sbOut,
                           (UWord) &CLG_(current_state).jmps_passed, jmps_passed, hWordTy);
   }
   CLG_ASSERT(clgs.bb->cjmp_count == cJumps);
   CLG_ASSERT(clgs.bb->instr_count = clgs.ii_index);

   /* Info for final exit from BB */
      {
         ClgJumpKind jk;

         if      (sbIn->jumpkind == Ijk_Call) jk = jk_Call;
         else if (sbIn->jumpkind == Ijk_Ret)  jk = jk_Return;
         else {
            jk = jk_Jump;
            if ((sbIn->next->tag == Iex_Const) &&
                     (IRConst2Addr(sbIn->next->Iex.Const.con) ==
                              origAddr + clgs.instr_offset))
               jk = jk_None;
         }
         clgs.bb->jmp[cJumps].jmpkind = jk;
         /* Instruction index of the call/ret at BB end
          * (it is wrong for fall-through, but does not matter) */
         clgs.bb->jmp[cJumps].instr = clgs.ii_index-1;
      }

      /* swap information of last exit with final exit if inverted */
      if (clgs.bb->cjmp_inverted) {
        ClgJumpKind jk;
        UInt instr;

        jk = clgs.bb->jmp[cJumps].jmpkind;
        clgs.bb->jmp[cJumps].jmpkind = clgs.bb->jmp[cJumps-1].jmpkind;
        clgs.bb->jmp[cJumps-1].jmpkind = jk;
        instr = clgs.bb->jmp[cJumps].instr;
        clgs.bb->jmp[cJumps].instr = clgs.bb->jmp[cJumps-1].instr;
        clgs.bb->jmp[cJumps-1].instr = instr;
      }


   if (clgs.seen_before) {
      CLG_ASSERT(clgs.bb->instr_len = clgs.instr_offset);
   } else {
      clgs.bb->instr_len = clgs.instr_offset;
   }

   CLG_DEBUG(3, "- instrument(BB %p): byteLen %u, CJumps %u\n",
             (void *)origAddr, clgs.bb->instr_len,
             clgs.bb->cjmp_count);
   if (cJumps > 0) {
      CLG_DEBUG(3, "                     [ ");
      for (i = 0; i < cJumps; i++)
         CLG_DEBUG(3, "%d ", clgs.bb->jmp[i].instr);
      CLG_DEBUG(3, "], last inverted: %s \n",
                clgs.bb->cjmp_inverted ? "yes":"no");
   }
   // Check the jumpkind.
   /* FIXME: mpj Unused ???
   if (sbIn->jumpkind == Ijk_Sys_syscall || sbIn->jumpkind == Ijk_Sys_int128
            || sbIn->jumpkind == Ijk_Sys_int32 || sbIn->jumpkind
            == Ijk_Sys_sysenter) {
      if (CLG_(clo).trace_instrs) {
         IRDirty * di = unsafeIRDirty_0_N(0, "set_gap",
                                          VG_(fnptr_to_fnentry(set_gap)), mkIRExprVec_0());
         addStmtToIRSB(clgs.sbOut, IRStmt_Dirty(di));
      }
   }
*/
   return clgs.sbOut;
}

