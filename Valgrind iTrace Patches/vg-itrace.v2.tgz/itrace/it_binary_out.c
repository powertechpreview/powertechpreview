/*--------------------------------------------------------------------*/
/*--- itrace                                                       ---*/
/*---                                              it_binary_out.c ---*/
/*--------------------------------------------------------------------*/

/*
   This file is part of itrace, a Valgrind tool for instruction tracing.
 
   Author:  Maynard Johnson <maynardj@us.ibm.com>
   (C) Copyright IBM Corporation 2012-2015

   This program is free software; you can redistribute it and/or
   modify it under the terms of the GNU General Public License as
   published by the Free Software Foundation; either version 2 of the
   License, or (at your option) any later version.

   This program is distributed in the hope that it will be useful, but
   WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA
   02111-1307, USA.

   The GNU General Public License is contained in the file COPYING.
 */

/*
 This files generates binary output for instruction tracing, which is
 the default mode of operation (or when explicitly passing the
 "--readable=no" option).
 */

#include "config.h"
#include "global.h"
#include "itrace.h"

#include <pub_tool_threadstate.h>
//# referencing these includes here will irritate the valgrind
//# check_include helper script.  What we need from them is rather
//# simple, so we will declare functions directly and be done with it.
//#include <pub_tool_libcfile.h>
//#include "../coregrind/pub_core_debuglog.h"
extern
void VG_(debugLog) ( Int level, const HChar* modulename,
                                const HChar* format, ... )
     __attribute__((format(__printf__, 3, 4)));

extern Int VG_(safe_fd) ( Int oldfd );

// bufsize seems to be arbitrarily set.
#define FWRITE_BUFSIZE 0x10000
#define FWRITE_THROUGH (0x9500)

static Char fwrite_buf[FWRITE_BUFSIZE];
static Int fwrite_pos;
static Int fwrite_fd = -1;
static const HChar * filename = NULL;

#define vgi_rec_len sizeof(VG_Itrace_record_t)
// vgi_rec_len is a rather small value..
// make little sense to be used as an
// index into the record buffer field here..
static Char vgi_rec_buf[vgi_rec_len]; // fudge ? --->>   + FN_NAME_LEN];

static
void file_err(void)
{
   VG_(message)(Vg_UserMsg,
            "Error: can not open itrace output file `%s'\n",
            filename );
   VG_(exit)(1);
}

// Note: it_flush does the actual write from the fwrite_buf to disk. Part of this
// process will reset the offset (fwrite_pos) to zero.
static __inline__
void it_flush(void)
{
   if ((fwrite_fd >= 0) && (fwrite_pos > 0))
      VG_(write)(fwrite_fd, (void*)fwrite_buf, fwrite_pos);
   fwrite_pos = 0;
}

static void my_fwrite(Char* buf, Int len)
{
   if (len > FWRITE_THROUGH) {
      it_flush();
      VG_(write)(fwrite_fd, (void*)buf, len);
      return;
   }
   if (FWRITE_BUFSIZE - fwrite_pos <= len)
      it_flush();
   VG_(memcpy)(fwrite_buf + fwrite_pos, buf, len);
   fwrite_pos += len;
}

void _itrace_begin_binary(void)
{
   VG_Itrace_record_t * rec = (VG_Itrace_record_t *)vgi_rec_buf;
   ULong magic = ITRACE_BIN_MAGIC_NUM;
   filename = CLG_(clo).binary_outfname;
   VG_(debugLog)(1,"Info"," Writing binary data to %s \n",filename);
   SysRes res = VG_(open)(filename, VKI_O_WRONLY|VKI_O_TRUNC, 0);

   if (sr_isError(res)) {
      res = VG_(open)(filename, VKI_O_CREAT|VKI_O_WRONLY,
               VKI_S_IRUSR|VKI_S_IWUSR);
      if (sr_isError(res)) {
         /* If the file can not be opened for whatever reason (conflict
          between multiple supervised processes?), give up now. */
         file_err();
      }
   }
   fwrite_fd = (Int) sr_Res(res);
   fwrite_fd = VG_(safe_fd)(fwrite_fd);
   // Write magic number twice
   my_fwrite((void *)&magic, sizeof(magic));
   my_fwrite((void *)&magic, sizeof(magic));
   rec->type = VG_BEGIN;
   rec->addr = ITRACE_HEADER_FILL;
   my_fwrite((Char *)rec, vgi_rec_len);
   it_flush();
}

void _finish_binary(void)
{
   VG_Itrace_record_t * rec = (VG_Itrace_record_t *)vgi_rec_buf;
   rec->type = VG_END;
   rec->addr = ITRACE_HEADER_FILL;
   my_fwrite((Char *)rec, vgi_rec_len);
   it_flush();
   VG_(debugLog)(1,"Info","Writing (flushing) data to disk.\n");
   VG_(close(fwrite_fd));
   VG_(debugLog)(1,"Info","Done writing data to disk.\n");
}

static Bool _should_do_trace(Bool is_insn)
{
   static Bool skip_ldst = False;
   Bool skip_tracing = False;

   if (CLG_(clo).num_insns_to_trace &&
            total_insns_traced >= CLG_(clo).num_insns_to_trace) {
      VG_(printf)("Finished collecting specified total number of instructions %lld . . . Quitting.\n",
                 CLG_(clo).num_insns_to_trace);
      it_flush();
      VG_(exit(0));
   }

   if (num_func_insns_skipped < CLG_(clo).num_insns_before_start)  {
      skip_tracing = True;
      if (increment_func_insns_skipped && is_insn)
         num_func_insns_skipped++;

      // If the last skipped instruction is a load or store, we want to
      // also skip the tracing of the 'W' or 'R' record.
      if (num_func_insns_skipped == CLG_(clo).num_insns_before_start)
         skip_ldst = True;
   } else if (skip_ldst) {
      skip_ldst = False;
      if (!is_insn)
         skip_tracing = True;
   } else {
      skip_ldst = False;
   }
   if (no_trace || skip_tracing) {
      ti = CLG_(get_current_thread)();
      ti->instrs_missed = True;
   }

   return !(no_trace | skip_tracing);
}


static VG_REGPARM(2)
void output_ldSt(Addr addr, UInt trc_type)
{
   VG_Itrace_record_t * rec;

   if (!_should_do_trace(False))
      return;
   //total_insns_traced++;

   rec  = (VG_Itrace_record_t *)vgi_rec_buf;
   CLG_ASSERT(trc_type == VG_READ || trc_type == VG_WRITE);
   rec->type = trc_type;
   rec->addr = addr;
   my_fwrite((Char *)rec, vgi_rec_len);
}

static void __get_instruction(InstrInfo* ii, VG_Itrace_record_t * rec) {
   Addr addr;

   CLG_ASSERT(ii->instr_size <= VG_MAX_INSTR_SZB);

   /* If instructions have been missed tracing in this thread, write a GAP record. */
   if (ti->instrs_missed) {
      ti->instrs_missed = False;
      rec->type = VG_GAP;
      my_fwrite((Char *)rec, vgi_rec_len);
   }

   addr = bb_base + ii->instr_offset;
   if (ii->instr_offset == 0) {
      rec->type = VG_JADDR;
   } else {
      rec->type = VG_INSN;
   }
   rec->addr = addr;
   rec->insn = *((UInt *)addr);
}

static VG_REGPARM(1)
void output_instruction(InstrInfo* ii)
{
   VG_Itrace_record_t * rec;
   if (!_should_do_trace(True))
      return;
   total_insns_traced++;
   rec = (VG_Itrace_record_t *)vgi_rec_buf;
   __get_instruction(ii, rec);
   my_fwrite((Char *)rec, vgi_rec_len);
}

/* Generate code for all outstanding memory events, and mark the queue
 empty.  Code is generated into cgs->sbOut, and this activity
 'consumes' slots in cgs->bb.
 */
void flushEvents_binary_out(ClgState* clgs)
{
   Int i, argc;
   UInt trc_type;
   const HChar* helperName;
   void* helperAddr;
   IRExpr *arg1 = 0, *arg2 = 0, **argv = 0;
   IRDirty* di;
   Event* ev;

   for (i = 0; i < clgs->events_used; i++) {
      /* generate IR to notify event i */
      tl_assert(i >= 0 && i < clgs->events_used);

      ev = &clgs->events[i];
      helperName = NULL;
      helperAddr = NULL;
      argv = NULL;

      CLG_DEBUGIF(5) {
         VG_(printf)("   flush ");
         showEvent(ev);
      }

      // Decide on helper fn to call and args to pass it.
      switch (ev->tag) {
         case Ev_Ir:
            helperName = "output_instruction";
            helperAddr = output_instruction;
            argc = 1;
            arg1 = mkIRExpr_HWord((HWord) ev->inode);
            break;
         case Ev_Dr:
         case Ev_Dw:
            argc = 2;
            arg1 = get_Event_dea(ev);
            helperName = "output_ldSt";
            helperAddr = output_ldSt;
            if (ev->tag == Ev_Dr)
               trc_type = VG_READ;
            else
               trc_type = VG_WRITE;
            arg2 = IRExpr_Const(IRConst_U32(trc_type));
            break;
         default:
            tl_assert(0);
      }

      // Add the helper.
      // Add call to the instrumentation function
      if (argc == 1)
         argv = mkIRExprVec_1(arg1);
      else if (argc == 2)
         argv = mkIRExprVec_2(arg1, arg2);
      di = unsafeIRDirty_0_N( /*regparms*/argc, helperName,
                              VG_(fnptr_to_fnentry)(helperAddr), argv);
      addStmtToIRSB(clgs->sbOut, IRStmt_Dirty(di));
   }
   clgs->events_used = 0;
}

/*------------------------------------------------------------*/
IRSB* itrace_binary_instrument(VgCallbackClosure* closure, IRSB* sbIn,
                               const VexGuestLayout* layout, const VexGuestExtents* vge, IRType gWordTy,
                               IRType hWordTy) {
   Int i, isize;
   IRStmt* st;
   Addr origAddr;
   Addr cia; /* address of current insn */
   InstrInfo* curr_inode = NULL;
   ClgState clgs;
   UInt cJumps = 0;
   IREndness endian;

   clgs.sbOut = NULL;
   if (gWordTy != hWordTy) {
      /* We don't currently support this case. */
      VG_(tool_panic)("host/guest word size mismatch");
   }

   // No instrumentation if it is switched off
   if (!CLG_(instrument_state)) {
      CLG_DEBUG(5, "instrument(BB 0x%llx) [Instrumentation OFF]\n",
                (unsigned long long)closure->readdr);
      return sbIn;
   }

   CLG_DEBUG(3, "+ instrument(BB  0x%llx)\n", (unsigned long long)closure->readdr);

   /* Set up SB for instrumented IR */
   clgs.sbOut = deepCopyIRSBExceptStmts(sbIn);

   // Copy verbatim any IR preamble preceding the first IMark
   i = 0;
   while (i < sbIn->stmts_used && sbIn->stmts[i]->tag != Ist_IMark) {
      addStmtToIRSB(clgs.sbOut, sbIn->stmts[i]);
      i++;
   }

   // Get the first statement, and origAddr from it
   CLG_ASSERT(sbIn->stmts_used >0);
   CLG_ASSERT(i < sbIn->stmts_used);
   st = sbIn->stmts[i];
   CLG_ASSERT(Ist_IMark == st->tag);

   origAddr = (Addr) st->Ist.IMark.addr;
   cia = st->Ist.IMark.addr;
   isize = st->Ist.IMark.len;
   CLG_ASSERT(origAddr == st->Ist.IMark.addr); // XXX: check no overflow

   /* Get BB struct (creating if necessary).
    * JS: The hash table is keyed with orig_addr_noredir -- important!
    * JW: Why? If it is because of different chasing of the redirection,
    *     this is not needed, as chasing is switched off in itrace
    */
   clgs.bb = CLG_(get_bb)(origAddr, sbIn, &(clgs.seen_before));

   addBBSetupCall(&clgs);

   // Set up running state
   clgs.events_used = 0;
   clgs.ii_index = 0;
   clgs.instr_offset = 0;

   for (/*use current i*/; i < sbIn->stmts_used; i++) {
      st = sbIn->stmts[i];
      CLG_ASSERT(isFlatIRStmt(st));

      switch (st->tag) {
         case Ist_NoOp:
         case Ist_AbiHint:
         case Ist_Put:
         case Ist_PutI:
         case Ist_MBE:
            break;

         case Ist_IMark: {
            cia = st->Ist.IMark.addr;
            isize = st->Ist.IMark.len;
            CLG_ASSERT(clgs.instr_offset == (Addr)cia - origAddr);
            // If Vex fails to decode an instruction, the size will be zero.
            // Pretend otherwise.
            if (isize == 0)
               isize = VG_MIN_INSTR_SZB;

            // Sanity-check size.
            tl_assert( (VG_MIN_INSTR_SZB <= isize && isize <= VG_MAX_INSTR_SZB)
                       || VG_CLREQ_SZB == isize );

            // Init the inode, record it as the current one.
            // Subsequent Dr/Dw/Dm events from the same instruction will
            // also use it.
            curr_inode = next_InstrInfo(&clgs, isize);
            addEvent_Ir(&clgs, curr_inode);
            break;
         }

         case Ist_WrTmp: {
            IRExpr* data = st->Ist.WrTmp.data;
            if (data->tag == Iex_Load) {
               IRExpr* aexpr = data->Iex.Load.addr;
               endian = data->Iex.Load.end;
               addEvent_Dr(&clgs, curr_inode, sizeofIRType(data->Iex.Load.ty),
                           aexpr, endian);
            }
            break;
         }

         case Ist_Store: {
            IRExpr* data = st->Ist.Store.data;
            IRExpr* aexpr = st->Ist.Store.addr;
            endian = st->Ist.Store.end;
            addEvent_Dw(&clgs, curr_inode, sizeofIRType(typeOfIRExpr(
                     sbIn->tyenv, data)), aexpr, endian);
            break;
         }

         case Ist_Dirty: {
            Int dataSize;
            IRDirty* d = st->Ist.Dirty.details;
            if (d->mFx != Ifx_None) {
               /* This dirty helper accesses memory.  Collect the details. */
               tl_assert(d->mAddr != NULL);
               tl_assert(d->mSize != 0);
               dataSize = d->mSize;
               // Large (eg. 28B, 108B, 512B on x86) data-sized
               // instructions will be done inaccurately, but they're
               // very rare and this avoids errors from hitting more
               // than two cache lines in the simulation.
               /*  FIXME: I am not sure how to get the endian from Ist_Dirty. */
               endian = Iend_BE;
               if (dataSize > MIN_LINE_SIZE)
                  dataSize = MIN_LINE_SIZE;
               if (d->mFx == Ifx_Read || d->mFx == Ifx_Modify)
                  addEvent_Dr(&clgs, curr_inode, dataSize, d->mAddr, endian);
               if (d->mFx == Ifx_Write || d->mFx == Ifx_Modify)
                  addEvent_Dw(&clgs, curr_inode, dataSize, d->mAddr, endian);
            } else {
               tl_assert(d->mAddr == NULL);
               tl_assert(d->mSize == 0);
            }
            break;
         }

         case Ist_LLSC: {
            IRExpr* aexpr = st->Ist.LLSC.addr;
            IRType dataTy;

            endian = st->Ist.LLSC.end;
            if (st->Ist.LLSC.storedata == NULL) {
               // LL
               dataTy = typeOfIRTemp(sbIn->tyenv, st->Ist.LLSC.result);
               addEvent_Dr(&clgs, curr_inode, sizeofIRType(dataTy),
                           aexpr, endian);
            } else {
               // SC
               dataTy  = typeOfIRExpr(sbIn->tyenv, st->Ist.LLSC.storedata);
               addEvent_Dw(&clgs, curr_inode, sizeofIRType(dataTy), aexpr, endian);
            }
            break;
         }

         case Ist_Exit: {
            Bool guest_exit, inverted;

            /* VEX code generation sometimes inverts conditional branches.
             * As Callgrind counts (conditional) jumps, it has to correct
             * inversions. The heuristic is the following:
             * (1) Callgrind switches off SB chasing and unrolling, and
             *     therefore it assumes that a candidate for inversion only is
             *     the last conditional branch in an SB.
             * (2) inversion is assumed if the branch jumps to the address of
             *     the next guest instruction in memory.
             * This heuristic is precalculated in CLG_(collectBlockInfo)().
             *
             * Branching behavior is also used for branch prediction. Note that
             * above heuristic is different from what Cachegrind does.
             * Cachegrind uses (2) for all branches.
             */
            if (cJumps + 1 == clgs.bb->cjmp_count)
               inverted = clgs.bb->cjmp_inverted;
            else
               inverted = False;

            // call branch predictor only if this is a branch in guest code
            guest_exit = (st->Ist.Exit.jk == Ijk_Boring) ||
                         (st->Ist.Exit.jk == Ijk_Call) ||
                         (st->Ist.Exit.jk == Ijk_Ret);

            if (guest_exit) {
               /* Stuff to widen the guard expression to a host word, so
                       we can pass it to the branch predictor simulation
                       functions easily. */
               IRType tyW = hWordTy;
               IROp widen = tyW == Ity_I32 ? Iop_1Uto32 : Iop_1Uto64;
               IROp opXOR = tyW == Ity_I32 ? Iop_Xor32 : Iop_Xor64;
               IRTemp guard1 = newIRTemp(clgs.sbOut->tyenv, Ity_I1);
               IRTemp guardW = newIRTemp(clgs.sbOut->tyenv, tyW);
               IRTemp guard = newIRTemp(clgs.sbOut->tyenv, tyW);
               IRExpr* one = tyW == Ity_I32 ? IRExpr_Const(IRConst_U32(1))
                                            : IRExpr_Const(IRConst_U64(1));

               /* Widen the guard expression. */
               addStmtToIRSB(clgs.sbOut, IRStmt_WrTmp(guard1,
                                                      st->Ist.Exit.guard));
               addStmtToIRSB(clgs.sbOut, IRStmt_WrTmp(guardW, IRExpr_Unop(
                        widen, IRExpr_RdTmp(guard1))));
               /* If the exit is inverted, invert the sense of the guard. */
               addStmtToIRSB(clgs.sbOut, IRStmt_WrTmp(guard,
                                                      inverted ? IRExpr_Binop(opXOR, IRExpr_RdTmp(guardW),
                                                                              one) : IRExpr_RdTmp(guardW)));
               /* No need for "branch" event since itrace inserts no simulation. */
            }

            /* We may never reach the next statement, so need to flush
             * all outstanding transactions now.
             */
            flushEvents_binary_out(&clgs);

            CLG_ASSERT(clgs.ii_index>0);
            if (!clgs.seen_before) {
               ClgJumpKind jk;

               if (st->Ist.Exit.jk == Ijk_Call)
                  jk = jk_Call;
               else if (st->Ist.Exit.jk == Ijk_Ret)
                  jk = jk_Return;
               else {
                  if (IRConst2Addr(st->Ist.Exit.dst) ==
                           origAddr + curr_inode->instr_offset + curr_inode->instr_size)
                     jk = jk_None;
                  else
                     jk = jk_Jump;
               }

               clgs.bb->jmp[cJumps].instr = clgs.ii_index-1;
               clgs.bb->jmp[cJumps].jmpkind = jk;
            }

            /* Update global variable jmps_passed before the jump
             * A correction is needed if VEX inverted the last jump condition
             */
            addConstMemStoreStmt(clgs.sbOut,
                                 (UWord) &CLG_(current_state).jmps_passed, inverted ? cJumps
                                                                                    + 1 : cJumps, hWordTy);
            cJumps++;
            break;
         }

         default:
            tl_assert(0);
            break;
      }
      /* Copy the original statement */
      addStmtToIRSB(clgs.sbOut, st);

      CLG_DEBUGIF(5) {
         VG_(printf)("   pass  ");
         ppIRStmt(st);
         VG_(printf)("\n");
      }
   }


   /* At the end of the bb.  Flush outstandings. */
   flushEvents_binary_out(&clgs);

   /* Always update global variable jmps_passed at end of bb.
    * A correction is needed if VEX inverted the last jump condition
    */
   {
      UInt jmps_passed = cJumps;
      if (clgs.bb->cjmp_inverted)
         jmps_passed--;
      addConstMemStoreStmt(clgs.sbOut,
                           (UWord) &CLG_(current_state).jmps_passed, jmps_passed, hWordTy);
   }
   CLG_ASSERT(clgs.bb->cjmp_count == cJumps);
   CLG_ASSERT(clgs.bb->instr_count = clgs.ii_index);

   /* Info for final exit from BB */
   {
      ClgJumpKind jk;

      if      (sbIn->jumpkind == Ijk_Call) jk = jk_Call;
      else if (sbIn->jumpkind == Ijk_Ret)  jk = jk_Return;
      else {
         jk = jk_Jump;
         if ((sbIn->next->tag == Iex_Const) &&
                  (IRConst2Addr(sbIn->next->Iex.Const.con) ==
                           origAddr + clgs.instr_offset))
            jk = jk_None;
      }
      clgs.bb->jmp[cJumps].jmpkind = jk;
      /* Instruction index of the call/ret at BB end
       * (it is wrong for fall-through, but does not matter) */
      clgs.bb->jmp[cJumps].instr = clgs.ii_index-1;
   }

   /* swap information of last exit with final exit if inverted */
   if (clgs.bb->cjmp_inverted) {
      ClgJumpKind jk;
      UInt instr;

      jk = clgs.bb->jmp[cJumps].jmpkind;
      clgs.bb->jmp[cJumps].jmpkind = clgs.bb->jmp[cJumps-1].jmpkind;
      clgs.bb->jmp[cJumps-1].jmpkind = jk;
      instr = clgs.bb->jmp[cJumps].instr;
      clgs.bb->jmp[cJumps].instr = clgs.bb->jmp[cJumps-1].instr;
      clgs.bb->jmp[cJumps-1].instr = instr;
   }

   if (clgs.seen_before) {
      CLG_ASSERT(clgs.bb->instr_len = clgs.instr_offset);
   } else {
      clgs.bb->instr_len = clgs.instr_offset;
   }

   CLG_DEBUG(3, "- instrument(BB %p): byteLen %u, CJumps %u\n",
             (void *)origAddr, clgs.bb->instr_len,
             clgs.bb->cjmp_count);
   if (cJumps > 0) {
      CLG_DEBUG(3, "                     [ ");
      for (i = 0; i < cJumps; i++)
         CLG_DEBUG(3, "%d ", clgs.bb->jmp[i].instr);
      CLG_DEBUG(3, "], last inverted: %s \n",
                clgs.bb->cjmp_inverted ? "yes":"no");
   }
   // Check the jumpkind.
   /* Unused??
   if (sbIn->jumpkind == Ijk_Sys_syscall || sbIn->jumpkind == Ijk_Sys_int128
            || sbIn->jumpkind == Ijk_Sys_int32 || sbIn->jumpkind
            == Ijk_Sys_sysenter) {
      if (CLG_(clo).trace_instrs) {
         IRDirty * di = unsafeIRDirty_0_N(0, "set_gap",
                                          VG_(fnptr_to_fnentry(set_gap)), mkIRExprVec_0());
         addStmtToIRSB(clgs.sbOut, IRStmt_Dirty(di));
      }
   }
   */
   return clgs.sbOut;
}
