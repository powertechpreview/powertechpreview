/*--------------------------------------------------------------------*/
/*--- itrace                                                       ---*/
/*---                                                     events.h ---*/
/*
 * This file is based on a similar file that is part of the callgrind tool,
 * written by Josef Weidendorfer:
 * Copyright (C) 2002-2006, Josef Weidendorfer (Josef.Weidendorfer@gmx.de)
 *
 *--------------------------------------------------------------------*/


/* Abstractions for 64-bit cost lists (events.h) */

#ifndef CG_EVENTS
#define CG_EVENTS

#include "pub_tool_basics.h"

#define CLG_(str) VGAPPEND(vgItrace_,str)

/* An event type */
typedef struct _EventType EventType;
struct _EventType {
  HChar* name;
  Char* description;
  Int id;
};

EventType* CLG_(register_eventtype)(const HChar*);
EventType* CLG_(get_eventtype)(const HChar*);
EventType* CLG_(get_eventtype_byindex)(Int id);

/* An event set is a ordered list of event types, which comes down
 * to some description for ordered lists of costs.
 * Often, costs of 2 event types are related, e.g. one is always smaller
 * than the other. This is useful to speed up arithmetics on cost lists:
 * Each event type in the set has a <nextTop>. All indexes before are
 * promised to hold smaller values than the current.
 */
typedef struct _EventSetEntry EventSetEntry;
struct _EventSetEntry {
  EventType* type;
  Int nextTop;
};
typedef struct _EventSet EventSet;
struct _EventSet {
  const HChar* name;
  Int size;
  Int capacity;
  EventSetEntry e[0];
};


/* Some events out of an event set.
 * Used to print out part of an EventSet, or in another order.
 */
typedef struct _EventMapping EventMapping;
struct _EventMapping {
  EventSet* set;
  Int size;
  Int capacity;
  Int index[0];
};

  
/* Allocate space for an event set */
EventSet* CLG_(get_eventset)(const HChar* n, Int capacity);
/* Incorporate a event type into a set, get start offset */
Int CLG_(add_eventtype)(EventSet* dst, EventType*);
/* Incorporate event types into a set, with ... < second < first */
Int CLG_(add_dep_event2)(EventSet* dst, EventType* e1, EventType* e2);
Int CLG_(add_dep_event3)(EventSet* dst,
			EventType* e1, EventType* e2, EventType* e3);
Int CLG_(add_dep_event4)(EventSet* dst,
			EventType* e1, EventType* e2, EventType* e3,
			EventType* e4);
/* Incorporate one event set into another, get start offset */
Int CLG_(add_eventset)(EventSet* dst, EventSet* src);
/* Allocate cost array for an event set */
ULong* CLG_(get_eventset_cost)(EventSet*);

/* Allocate space for an event mapping */
EventMapping* CLG_(get_eventmapping)(EventSet*);
void CLG_(append_event)(EventMapping*, const HChar*);
#endif /* CG_EVENTS */
