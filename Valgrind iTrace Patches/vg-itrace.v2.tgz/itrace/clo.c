/*--------------------------------------------------------------------*/
/*--- itrace                                                       ---*/
/*---                                                        clo.c ---*/
/*--------------------------------------------------------------------*/

/*
   This file is part of itrace, a Valgrind tool for instruction tracing.

   Authors: Dave Nomura (dcnomura@us.ibm.com) and Maynard Johnson
            (maynardj@us.ibm.com)
   (C) Copyright IBM Corporation 2006 - 2015

   This file is based on a similar file that is part of the callgrind tool,
   written by Josef Weidendorfer:
   Copyright (C) 2002-2006, Josef Weidendorfer (Josef.Weidendorfer@gmx.de)

   This program is free software; you can redistribute it and/or
   modify it under the terms of the GNU General Public License as
   published by the Free Software Foundation; either version 2 of the
   License, or (at your option) any later version.

   This program is distributed in the hope that it will be useful, but
   WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA
   02111-1307, USA.

   The GNU General Public License is contained in the file COPYING.
*/

#include "config.h" // for VG_PREFIX

#include "global.h"



/*------------------------------------------------------------*/
/*--- Function specific configuration options              ---*/
/*------------------------------------------------------------*/

/* Special value for separate_callers: automatic = adaptive */
#define CONFIG_AUTO    -1

#define CONFIG_DEFAULT -1
#define CONFIG_FALSE    0
#define CONFIG_TRUE     1

const HChar* default_fnname = "_dl_runtime_resolve";

/* Logging configuration for a function */
struct _fn_config {
    Int dump_before;
    Int dump_after;
    Int zero_before;
    Int toggle_collect;

    Int skip;    /* Handle CALL to this function as JMP (= Skip)? */
    Int group;   /* don't change caller dependency inside group !=0 */
    Int pop_on_jump; 

  //Int separate_callers;    /* separate logging dependent on caller  */
    Int separate_recursions; /* separate logging of rec. levels       */

#if CLG_ENABLE_DEBUG
    Int verbosity; /* Change debug verbosity level while in function */
#endif
};

/* Configurations for function name prefix patterns.
 * Currently, only very limit patterns are possible:
 * Exact prefix patterns and "*::" are allowed.
 * E.g.
 *  - "abc" matches all functions starting with "abc".
 *  - "abc*::def" matches all functions starting with "abc" and
 *    starting with "def" after the first "::" separator.
 *  - "*::print(" matches C++ methods "print" in all classes
 *    without namespace. I.e. "*" doesn't match a "::".
 *
 * We build a trie from patterns, and for a given function, we
 * go down the tree and apply all non-default configurations.
 */


#define NODE_DEGREE 30

/* node of compressed trie search structure */
typedef struct _config_node config_node;
struct _config_node {
  Int length;
    
  fn_config* config;
  config_node* sub_node[NODE_DEGREE];
  config_node* next;
  config_node* wild_star;
  config_node* wild_char;

  Char name[1];
};

/* root of trie */
static config_node* fn_configs = 0;

static __inline__ 
fn_config* new_fnc(void)
{
   fn_config* new = (fn_config*) CLG_MALLOC("clo.nf", sizeof(fn_config));

   new->skip         = CONFIG_DEFAULT;
   new->pop_on_jump  = CONFIG_DEFAULT;
   new->group        = CONFIG_DEFAULT;
   new->separate_recursions = CONFIG_DEFAULT;

#if CLG_ENABLE_DEBUG
   new->verbosity    = CONFIG_DEFAULT;
#endif
   return new;
}


static config_node* new_config(const HChar* name, int length)
{
    int i;
    config_node* node = (config_node*) CLG_MALLOC("clo.nc", sizeof(config_node) + length);

    for(i=0;i<length;i++) {
      if (name[i] == 0) break;
      node->name[i] = name[i];
    }
    node->name[i] = 0;

    node->length = length;
    node->config = 0;
    for(i=0;i<NODE_DEGREE;i++)
	node->sub_node[i] = 0;
    node->next = 0;
    node->wild_char = 0;
    node->wild_star = 0;

    CLG_DEBUG(3, "   new_config('%s', len %d)\n", node->name, length);

    return node;
}

static __inline__
Bool is_wild(Char n)
{
  return (n == '*') || (n == '?');
}

/* Recursively build up function matching tree (prefix tree).
 * Returns function config object for pattern <name>
 * and starting at tree node <*pnode>.
 *
 * Tree nodes (config_node) are created as needed,
 * tree root is stored into <*pnode>, and the created
 * leaf (fn_config) for the given pattern is returned.
 */
static fn_config* get_fnc2(config_node* node, const HChar* name)
{
  config_node *new_sub, *n, *nprev;
  int offset, len;

  CLG_DEBUG(3, "  get_fnc2(%p, '%s')\n", node, name);

  if (name[0] == 0) {
    if (!node->config) node->config = new_fnc();
    return node->config;
  }

  if (is_wild(*name)) {
    if (*name == '*') {
      while(name[1] == '*') name++;
      new_sub = node->wild_star;
    }
    else
      new_sub = node->wild_char;

    if (!new_sub) {
      new_sub = new_config(name, 1);
      if (*name == '*')
	node->wild_star = new_sub;
      else
	node->wild_char = new_sub;
    }

    return get_fnc2( new_sub, name+1);
  }

  n = node->sub_node[ name[0]%NODE_DEGREE ];
  nprev = 0;
  len = 0;
  while(n) {
    for(len=0; name[len] == n->name[len]; len++);
    if (len>0) break;
    nprev = n;
    n = n->next;
  }

  if (!n) {
    len = 1;
    while(name[len] && (!is_wild(name[len]))) len++;
    new_sub = new_config(name, len);
    new_sub->next = node->sub_node[ name[0]%NODE_DEGREE ];
    node->sub_node[ name[0]%NODE_DEGREE ] = new_sub;	

    if (name[len] == 0) {
      new_sub->config = new_fnc();
      return new_sub->config;
    }
    
    /* recurse on wildcard */
    return get_fnc2( new_sub, name+len);
  }

  if (len < n->length) {

    /* split up the subnode <n> */
    config_node *new_node;
    int i;

    new_node = new_config((const HChar *)n->name, len);
    if (nprev)
      nprev->next = new_node;
    else
      node->sub_node[ n->name[0]%NODE_DEGREE ] = new_node;
    new_node->next = n->next;

    new_node->sub_node[ n->name[len]%NODE_DEGREE ] = n;

    for(i=0, offset=len; offset < n->length; i++, offset++)
      n->name[i] = n->name[offset];
    n->name[i] = 0;
    n->length = i;

    name += len;
    offset = 0;
    while(name[offset] && (!is_wild(name[offset]))) offset++;
    new_sub  = new_config(name, offset);
    /* this sub_node of new_node could already be set: chain! */
    new_sub->next = new_node->sub_node[ name[0]%NODE_DEGREE ];
    new_node->sub_node[ name[0]%NODE_DEGREE ] = new_sub;

    if (name[offset]==0) {
      new_sub->config = new_fnc();
      return new_sub->config;
    }

    /* recurse on wildcard */
    return get_fnc2( new_sub, name+offset);
  }

  name += n->length;

  if (name[0] == 0) {
    /* name and node name are the same */
    if (!n->config) n->config = new_fnc();
    return n->config;
  }

  offset = 1;
  while(name[offset] && (!is_wild(name[offset]))) offset++;

  new_sub = new_config(name, offset);
  new_sub->next = n->sub_node[ name[offset]%NODE_DEGREE ];
  n->sub_node[ name[offset]%NODE_DEGREE ] = new_sub;	

  return get_fnc2(new_sub, name+offset);
}

static void print_config_node(int s, config_node* node)
{
  config_node* n;
  int i;

  if (node != fn_configs) {
    char sp[] = "                                        ";

    if (s>40) s=40;
    VG_(printf)("%s",sp+40-s);
    VG_(printf)("'%s'/%d\n", node->name, node->length);
  }
  for(i=0;i<NODE_DEGREE;i++) {
    n = node->sub_node[i];
    while(n) {
      print_config_node(s+1, n);
      n = n->next;
    }
  }
  if (node->wild_char) print_config_node(s+1, node->wild_char);
  if (node->wild_star) print_config_node(s+1, node->wild_star);
}

/* get a function config for a name pattern (from command line) */
static fn_config* get_fnc(const HChar* name)
{
  fn_config* fnc;

  CLG_DEBUG(3, " +get_fnc(%s)\n", name);
  if (fn_configs == 0)
    fn_configs = new_config(name, 0);
  fnc =  get_fnc2(fn_configs, name);

  CLG_DEBUGIF(3) {
    CLG_DEBUG(3, " -get_fnc(%s):\n", name);
    print_config_node(3, fn_configs);
  }
  return fnc;
}

  

static void update_fn_config1(fn_node* fn, fn_config* fnc)
{

    if (fnc->skip != CONFIG_DEFAULT)
	fn->skip = (fnc->skip == CONFIG_TRUE);

    if (fnc->pop_on_jump != CONFIG_DEFAULT)
	fn->pop_on_jump = (fnc->pop_on_jump == CONFIG_TRUE);

    if (fnc->group != CONFIG_DEFAULT)
	fn->group = fnc->group;

#if CLG_ENABLE_DEBUG
    if (fnc->verbosity != CONFIG_DEFAULT)
	fn->verbosity = fnc->verbosity;
#endif
}

/* Recursively go down the function matching tree,
 * looking for a match to <name>. For every matching leaf,
 * <fn> is updated with the pattern config.
 */
static void update_fn_config2(fn_node* fn, Char* name, config_node* node)
{
    config_node* n;

    CLG_DEBUG(3, "  update_fn_config2('%s', node '%s'): \n",
	     name, node->name);
    if ((*name == 0) && node->config) {
      CLG_DEBUG(3, "Found!\n");
      update_fn_config1(fn, node->config);
      return;
    }

    n = node->sub_node[ name[0]%NODE_DEGREE ];
    while(n) {
      if (VG_(strncmp)((HChar *)name,(HChar *) n->name, n->length)==0) break;
      n = n->next;
    }
    if (n) update_fn_config2(fn, name+n->length, n);
    
    if (node->wild_char)
      update_fn_config2(fn, name+1, node->wild_char);

    if (node->wild_star) {
      while(*name) {
	update_fn_config2(fn, name, node->wild_star);
	name++;
      }
      update_fn_config2(fn, name, node->wild_star);
    }
}

/* Update function config according to configs of name prefixes */
void CLG_(update_fn_config)(fn_node* fn)
{
    CLG_DEBUG(3, "  update_fn_config('%s')\n", fn->name);
    if (fn_configs)
      update_fn_config2(fn, (Char *)fn->name, fn_configs);
}


/*--------------------------------------------------------------------*/
/*--- Command line processing                                      ---*/
/*--------------------------------------------------------------------*/

__attribute__((unused))
static UWord getUWord(const Char* s)
{
    UWord n = 0;
    Bool isHex = False;

    CLG_DEBUG(3, "  get_UWord('%s')\n", s);
    if ((s[0] == '0') && (s[1] == 'x')) {
	isHex = True;
	s += 2;
    }

    if (!isHex) {
	while((*s >='0') && (*s <='9')) {
	    n = 10*n + (*s-'0');
	    s++;
	}
    }
    else {
	while(1) {
	    if ((*s >='0') && (*s <='9')) {
		n = 16*n + (*s-'0');
		s++;
		continue;
	    }
	    if ((*s >='a') && (*s <='f')) {
		n = 16*n + (*s-'a'+10);
		s++;
		continue;
	    }
	    if ((*s >='A') && (*s <='F')) {
		n = 16*n + (*s-'A'+10);
		s++;
		continue;
	    }
	    break;
	}
    }
    return n;
}

static UWord get_UWord_with_units(const HChar * s)
{
	UWord n=0;
    CLG_DEBUG(3, "  get_UWord_with_units('%s')\n", s);
	n=getUWord((const Char *) s);
    CLG_DEBUG(1, "  prefix ('%d')\n", (int)n);
	char unit;
/* grab the last character.  Note that this may be part of the number that has already been processed via getUWord above.*/
	unit = s[VG_(strlen)(s)-1];

    CLG_DEBUG(1, "  Units value [%c] \n",unit);

        /* This will be a common case, the unit is unspecified, so the
         *  char being checked here will be the last char in the word
         *  handled above.  */
        if ( (unit >= '0' && unit <='9') ||
             (unit >= 'a' && unit <='f') ||
             (unit >= 'A' && unit <='F') ) return n;
        switch(unit) {
          case 'k':
          case 'K':
             n*=1024;
             break;
          case 'm':
          case 'M':
             n*=(1024*1024);
             break;
          case 'g':
          case 'G':
             n*=(1024*1024*1024);
             break;
          default:
            CLG_DEBUG(1, "Unhandled units value. [%c] on parameter [%s].\n",unit,s);
        }
    CLG_DEBUG(1, "  Units value [%c] was detected.  Value is now [%d] \n",unit,(int)n);
    return n;
}

Bool CLG_(process_cmd_line_option)(const HChar* arg)
{
  const HChar * func_name;
  CLG_DEBUG(1, "  process_cmd_line_option ('%s')\n", arg);
  if VG_STR_CLO(arg, "--fnname", CLG_(clo).fnname){ }
  else if VG_INT_CLO(arg, "--num-insns-before-start", CLG_(clo).num_insns_before_start) {}
  else if VG_INT_CLO(arg, "--num-func-calls-before-start", CLG_(clo).num_func_calls_before_start) {}
  else if VG_INT_CLO(arg, "--num-K-insns-to-collect", CLG_(clo).num_insns_to_trace) {
    /* As --help text says, the unit for this value is 1,000s of instructions. */
    CLG_(clo).num_insns_to_trace*=1000;
  }
  else if VG_STREQN(23,arg, "--num-insns-to-collect=") {
    CLG_(clo).num_insns_to_trace=get_UWord_with_units((const HChar *)arg+23);
  }
  else if VG_STR_CLO(arg, "--binary-outfile", CLG_(clo).binary_outfname){ }
  else if VG_BOOL_CLO(arg, "--trace-instrs", CLG_(clo).trace_instrs) {}
  else if VG_BOOL_CLO(arg, "--trace-mem", CLG_(clo).trace_mem) {}
  else if VG_XACT_CLO(arg, "--trace-extent=calltree", CLG_(clo).trace, Lk_TrxtCalltree) {}
  else if VG_XACT_CLO(arg, "--trace-extent=all", CLG_(clo).trace, Lk_TrxtAll) {}
  else if VG_XACT_CLO(arg, "--trace-extent=function", CLG_(clo).trace, Lk_TrxtFunction) {}
  else if VG_BOOL_CLO(arg, "--readable", CLG_(clo).readable) {}
  else if VG_BOOL_CLO(arg, "--skip-plt", CLG_(clo).skip_plt) {}
  else if VG_XACT_CLO(arg, "--itrace-version", CLG_(clo).print_version, True) {}
  /* compatibility alias, deprecated option */
  else if VG_BOOL_CLO(arg, "--trace-jump", CLG_(clo).collect_jumps) {}
  else if VG_BOOL_CLO(arg, "--separate-threads", CLG_(clo).separate_threads) {}
  else if VG_STR_CLO(arg, "--fn-skip", func_name) {
    fn_config* fnc = get_fnc(func_name);
    fnc->skip = CONFIG_TRUE;
   }
  else if VG_STR_CLO(arg, "--fn-start", CLG_(clo).function_trigger) {
    function_trigger_started=0;
  }

  /* change handling of a jump between functions to ret+call */
  else if VG_XACT_CLO(arg, "--pop-on-jump", CLG_(clo).pop_on_jump, True) {}
  else if VG_STR_CLO(arg, "--pop-on-jump", func_name) {
    fn_config* fnc = get_fnc(func_name);
    fnc->pop_on_jump = CONFIG_TRUE;
  }
  else if VG_XACT_CLO(arg,"--dump-loadmap", CLG_(clo).dump_loadmap, True) { }
  else if VG_STR_CLO(arg,"--loadmap-outfile", CLG_(clo).loadmap_outfname) { }

#if CLG_ENABLE_DEBUG
   else if VG_INT_CLO(arg, "--ct-verbose", CLG_(clo).verbose) {}
   else if VG_INT_CLO(arg, "--ct-vstart", CLG_(clo).verbose_start) {}
   else if VG_STREQN(12, arg, "--ct-verbose") {
       HChar* s;
       fn_config* fnc;
       UInt n = VG_(strtoll10)(arg+12, &s);
       if ((n <= 0) || *s != '=') return False;
       fnc = get_fnc(s+1);
       fnc->verbosity = n;
   }
#endif
   else if VG_STREQN(10, arg, "--fn-group") {
       HChar* s;
       fn_config* fnc;
       UInt n = VG_(strtoll10)(arg+10, &s);
       if ((n <= 0) || *s != '=') return False;
       fnc = get_fnc(s+1);
       fnc->group = n;
   }
   else if VG_STREQN(15, arg, "--separate-recs") {
       HChar* s;
       fn_config* fnc;
       UInt n = VG_(strtoll10)(arg+15, &s);
       if ((n <= 0) || *s != '=') return False;
       fnc = get_fnc(s+1);
       fnc->separate_recursions = n;
   }
   else
     return False;

  return True;
}

void _print_usage(void);
void _print_usage(void)
{
   VG_(printf)(
"\n   data collection options:\n"
"    --binary-outfile=<file>   Name of binary output file (with --readable=no).[itrace_out.vgi]\n"
"    --readable=no|yes         Produce readable (text-based) output [no -- produce binary output]\n"
"    --dump-loadmap            Output DSO load start address, offset, and size info\n"
"    --loadmap-outfile=<file>  Specify loadmap file [itrace_out.map or the specified binary-outfile\n"
"                              name with everything after the last . replaced with \"map\"]\n"
"    --trace-instrs=yes|no     Trace executed instructions[yes]\n"
"    --trace-mem=yes|no        Trace memory access[yes]\n"
"    --trace-extent=calltree|all|function\n"
"                              Extent of trace instructions and memory access[calltree]\n"
"                              NOTE: --trace-extent=all is incompatible with --fnname option.\n"
"    --fnname=<func>           Function to be traced.[_dl_runtime_resolve]\n"
"                              NOTE: Use --demangle=no to specify a mangled C++ function name,\n"
"                                    and do not include leading '.'.\n"
"    --fn-start=<func> (Optional).  Do not begin tracing until this function is entered. \n"
"\n   The Next three options can be used independently or in any combination\n"
"    --num-insns-before-start  Number of instructions to skip (in given 'fnname') before tracing starts\n"
"    --num-func-calls-before-start\n"
"                              Number of times the given 'fnname' is called before tracing starts\n"
"    --num-K-insns-to-collect  Total number of k-instructions (units in 1,000's of instructions) to record\n"
"    --num-insns-to-collect=NNN{k|m|g}  Total number of instructions to collect, optionally with magnitudes\n"
"                              of k, m, g.  (k=1024)\n"
"                              Execution ends when specified number of instructions have been collected."
"\n   cost entity separation options:\n"
"    --separate-threads=no|yes Separate data per thread [no]\n"
"    --skip-plt=no|yes         Ignore calls to/from PLT sections[yes]\n"
"    --fn-skip=<function>      Ignore calls to/from function\n"
"    --itrace-version          Print the valgrind-itrace version.  All tracing options ignored, but\n"
"                              you must pass an app or command to trace (Valgrind's rules --not itrace's)\n"
"                              Example: valgrind --tool=itrace --itrace-version ls > /dev/null\n"
#if CLG_EXPERIMENTAL
"    --fn-group<no>=<func>     Put function into separation group <no>\n"
#endif
    );
}

void CLG_(print_usage)(void)
{
   _print_usage();
}

void CLG_(print_debug_usage)(void)
{
    VG_(printf)(

#if CLG_ENABLE_DEBUG
"    --ct-verbose=<level>       Verbosity of standard debug output [0]\n"
"    --ct-vstart=<BB number>    Only be verbose after basic block [0]\n"
"    --ct-verbose<level>=<func> Verbosity while in <func>\n"
#else
"    (none)\n"
#endif

    );
}

static const HChar* default_binary_outfile = "itrace_out.vgi";

void CLG_(set_clo_defaults)(void)
         {
   /* Default values for command line arguments */
   CLG_(clo).fnname = default_fnname;
   CLG_(clo).function_trigger = default_fnname;
   CLG_(clo).num_insns_before_start = 0;
   CLG_(clo).num_insns_to_trace = 0;
   CLG_(clo).num_func_calls_before_start = 0;
   CLG_(clo).binary_outfname = default_binary_outfile;
   CLG_(clo).loadmap_outfname = NULL;
   CLG_(clo).dump_loadmap = False;
   CLG_(clo).trace_instrs = True;
   CLG_(clo).trace_mem = True;
   CLG_(clo).print_version = False;
   CLG_(clo).trace = Lk_TrxtCalltree;
   CLG_(clo).readable = False;

   /* Collection */
   CLG_(clo).separate_threads = False;
   CLG_(clo).collect_jumps    = False;

   CLG_(clo).skip_plt         = False;

   /* Call graph */
   CLG_(clo).pop_on_jump = False;

#if CLG_ENABLE_DEBUG
   CLG_(clo).verbose = 0;
   CLG_(clo).verbose_start = 0;
#endif
}
