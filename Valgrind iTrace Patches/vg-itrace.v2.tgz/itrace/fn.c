/*--------------------------------------------------------------------*/
/*--- itrace                                                       ---*/
/*---                                                         fn.c ---*/
/*--------------------------------------------------------------------*/

/*
   This file is part of itrace, a Valgrind tool for instruction tracing.

   Authors: Dave Nomura (dcnomura@us.ibm.com) and Maynard Johnson
            (maynardj@us.ibm.com)
   (C) Copyright IBM Corporation 2006 - 2015

   This file is based on a similar file that is part of the callgrind tool,
   written by Josef Weidendorfer:
   Copyright (C) 2002-2006, Josef Weidendorfer (Josef.Weidendorfer@gmx.de)

   This program is free software; you can redistribute it and/or
   modify it under the terms of the GNU General Public License as
   published by the Free Software Foundation; either version 2 of the
   License, or (at your option) any later version.

   This program is distributed in the hope that it will be useful, but
   WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA
   02111-1307, USA.

   The GNU General Public License is contained in the file COPYING.
*/

#include "global.h"

extern Int VG_(safe_fd) ( Int oldfd );

#define N_INITIAL_FN_ARRAY_SIZE 10071

static fn_array current_fn_active;

static Addr runtime_resolve_addr = 0;
static int  runtime_resolve_length = 0;

/* _ld_runtime_resolve, located in ld.so, needs special handling:
 * The jump at end into the resolved function should not be
 * represented as a call (as usually done in callgrind with jumps),
 * but as a return + call. Otherwise, the repeated existence of
 * _ld_runtime_resolve in call chains will lead to huge cycles,
 * making the profile almost worthless.
 *
 * If ld.so is stripped, the symbol will not appear. But as this
 * function is handcrafted assembler, we search for it.
 *
 * Returns 0 if code not found, otherwise start address
 */
static void search_runtime_resolve(obj_node* obj)
{
	/* We do not check target address of <fixup>, therefore we have >1 ranges.
	 * We use a tuple sequence (offset,length) into the code array for this
	 */

#if defined(VGP_x86_linux)
	/* Check ranges [0-11], [16-23] */
	static int  code_offsets[] = { 0, 12, 16, 8, 24, 0 };
	static unsigned char code[] = {
			/* 0*/ 0x50, 0x51, 0x52, 0x8b, 0x54, 0x24, 0x10, 0x8b,
			/* 8*/ 0x44, 0x24, 0x0c, 0xe8, 0x70, 0x01, 0x00, 0x00,
			/*16*/ 0x5a, 0x59, 0x87, 0x04, 0x24, 0xc2, 0x08, 0x00 };
#else
#if defined(VGP_ppc32_linux)
	static int  code_offsets[] = {0, 65, 68, 64, 132, 0 };
	static unsigned char code[] = {
			/* 0*/ 0x94, 0x21, 0xff, 0xc0, 0x90, 0x01, 0x00, 0x0c,
			/* 8*/ 0x90, 0x61, 0x00, 0x10, 0x90, 0x81, 0x00, 0x14,
			/*16*/ 0x7d, 0x83, 0x63, 0x78, 0x90, 0xa1, 0x00, 0x18,
			/*24*/ 0x7d, 0x64, 0x5b, 0x78, 0x90, 0xc1, 0x00, 0x1c,
			/*32*/ 0x7c, 0x08, 0x02, 0xa6, 0x90, 0xe1, 0x00, 0x20,
			/*40*/ 0x90, 0x01, 0x00, 0x30, 0x91, 0x01, 0x00, 0x24,
			/*48*/ 0x7c, 0x00, 0x00, 0x26, 0x91, 0x21, 0x00, 0x28,
			/*56*/ 0x91, 0x41, 0x00, 0x2c, 0x90, 0x01, 0x00, 0x08,
			/*64*/ 0x48, 0x00, 0x02, 0x91, 0x7c, 0x69, 0x03, 0xa6, /* at 64: bl aff0 <fixup> */
			/*72*/ 0x80, 0x01, 0x00, 0x30, 0x81, 0x41, 0x00, 0x2c,
			/*80*/ 0x81, 0x21, 0x00, 0x28, 0x7c, 0x08, 0x03, 0xa6,
			/*88*/ 0x81, 0x01, 0x00, 0x24, 0x80, 0x01, 0x00, 0x08,
			/*96*/ 0x80, 0xe1, 0x00, 0x20, 0x80, 0xc1, 0x00, 0x1c,
			/*104*/0x7c, 0x0f, 0xf1, 0x20, 0x80, 0xa1, 0x00, 0x18,
			/*112*/0x80, 0x81, 0x00, 0x14, 0x80, 0x61, 0x00, 0x10,
			/*120*/0x80, 0x01, 0x00, 0x0c, 0x38, 0x21, 0x00, 0x40,
			/*128*/0x4e, 0x80, 0x04, 0x20 };
#else
#if defined(VGP_amd64_linux)
	/* x86_64 */
	static int  code_offsets[] = {0, 62, 66, 44, 110, 0 };
	static unsigned char code[] = {
			/* 0*/ 0x48, 0x83, 0xec, 0x38, 0x48, 0x89, 0x04, 0x24,
			/* 8*/ 0x48, 0x89, 0x4c, 0x24, 0x08, 0x48, 0x89, 0x54, 0x24, 0x10,
			/*18*/ 0x48, 0x89, 0x74, 0x24, 0x18, 0x48, 0x89, 0x7c, 0x24, 0x20,
			/*28*/ 0x4c, 0x89, 0x44, 0x24, 0x28, 0x4c, 0x89, 0x4c, 0x24, 0x30,
			/*38*/ 0x48, 0x8b, 0x74, 0x24, 0x40, 0x49, 0x89, 0xf3,
			/*46*/ 0x4c, 0x01, 0xde, 0x4c, 0x01, 0xde, 0x48, 0xc1, 0xe6, 0x03,
			/*56*/ 0x48, 0x8b, 0x7c, 0x24, 0x38, 0xe8, 0xee, 0x01, 0x00, 0x00,
			/*66*/ 0x49, 0x89, 0xc3, 0x4c, 0x8b, 0x4c, 0x24, 0x30,
			/*74*/ 0x4c, 0x8b, 0x44, 0x24, 0x28, 0x48, 0x8b, 0x7c, 0x24, 0x20,
			/*84*/ 0x48, 0x8b, 0x74, 0x24, 0x18, 0x48, 0x8b, 0x54, 0x24, 0x10,
			/*94*/ 0x48, 0x8b, 0x4c, 0x24, 0x08, 0x48, 0x8b, 0x04, 0x24,
			/*103*/0x48, 0x83, 0xc4, 0x48, 0x41, 0xff, 0xe3 };
#else
	/* Unknown platform, no check is done */
	static int  code_offsets[] = {0, 0 };
	static unsigned char code[] = { 0 };
#endif
#endif
#endif

	int *range = &(code_offsets[0]), *r = 0;
	Bool found = False;
	Addr addr, end;

	/* Only search in libraries with a given name pattern */
	if ((VG_(strncmp)(obj->name, "/lib/ld", 7) != 0) &&
			(VG_(strncmp)(obj->name, "/lib64/ld", 9) != 0)) return;

	CLG_DEBUG(1, "search_rs: Checking %d bytes of [%x ...]\n",
			range[1], code[0]);

	end = obj->start + obj->size - range[1];
	addr = obj->start;

	if (range[1] == 0) return;

	while(addr < end) {
		if (VG_(memcmp)( (void*)addr, code, range[1]) == 0) {

			r = range + 2;
			found = True;
			while(r[1]) {
				CLG_DEBUG(1, " [%p] Found! Checking %d bytes of [%x %x %x...]\n",
						(void *)addr, r[1], code[r[0]], code[r[0]+1], code[r[0]+2]);

				if (VG_(memcmp)( (void*)(addr+r[0]), code+r[0], r[1]) != 0) {
					found = False;
					break;
				}
				r += 2;
			}
			if (found) break;
		}
		addr++;
	}

	if (!found || (r==0)) return;

	if (VG_(clo_verbosity) > 1)
		VG_(message)(Vg_DebugMsg, "Code check found runtime_resolve: %s +%p=%p, length %d",
				obj->name + obj->last_slash_pos,
				(void *)(addr - obj->start), (void *)addr, r[0]);

	runtime_resolve_addr   = addr;
	runtime_resolve_length = r[0];
}

static Int map_fwrite_fd = -1;

static void open_loadmap_file(void)
{
    if ( CLG_(clo).loadmap_outfname == NULL ) {
	HChar *dot;
	/* allocate space for copy of filename plus ".map" plus nul */
	HChar temp_outfname[VG_(strlen)(CLG_(clo).binary_outfname) + 5];
	VG_(strcpy)(temp_outfname, CLG_(clo).binary_outfname);
	dot = VG_(strrchr)(temp_outfname,'.');
	if ( dot == NULL ) {
	    VG_(strcat)(temp_outfname, ".map");
	} else {
	    VG_(strcpy)(dot,".map");
	}
	CLG_(clo).loadmap_outfname = temp_outfname;
    }
    
    SysRes res = VG_(open)(CLG_(clo).loadmap_outfname, VKI_O_WRONLY|VKI_O_TRUNC, 0);
    
    if (sr_isError(res)) {
	res = VG_(open)(CLG_(clo).loadmap_outfname, VKI_O_CREAT|VKI_O_WRONLY,
			VKI_S_IRUSR|VKI_S_IWUSR);
	if (sr_isError(res)) {
	    VG_(message)(Vg_UserMsg,
			 "Error: can not open itrace load map output file `%s'\n",
			 CLG_(clo).loadmap_outfname);
	    VG_(exit)(1);
	}
    }
    map_fwrite_fd = (Int) sr_Res(res);
    map_fwrite_fd = VG_(safe_fd)(map_fwrite_fd);
    
    CLG_DEBUG(3,"loadmap file '%s' opened\n", CLG_(clo).loadmap_outfname);
}

static void record_obj_info(obj_node *node)
{
    char buf[100];
    if ( map_fwrite_fd == -1 ) {
	/* first time. figure out filename if necessary, and open for write */
	open_loadmap_file();
    }

    VG_(write)(map_fwrite_fd,node->name,VG_(strlen)(node->name));
    
    VG_(sprintf)(buf," 0x%lx 0x%lx 0x%lx\n",node->start,node->offset,node->size);

    VG_(write)(map_fwrite_fd,buf,VG_(strlen)(buf));
}

/*------------------------------------------------------------*/
/*--- Object/File/Function hash entry operations           ---*/
/*------------------------------------------------------------*/

/* Object hash table, fixed */
static obj_node* obj_table[N_OBJ_ENTRIES];

void CLG_(init_obj_table)()
		{
	Int i;
	for (i = 0; i < N_OBJ_ENTRIES; i++)
		obj_table[i] = 0;
		}

#define HASH_CONSTANT   256

static UInt str_hash(const HChar *s, UInt table_size)
{
	int hash_value = 0;
	for ( ; *s; s++)
		hash_value = (HASH_CONSTANT * hash_value + *s) % table_size;
	return hash_value;
}


static const HChar* anonymous_obj = "???";

static __inline__ 
obj_node* new_obj_node(DebugInfo* di, obj_node* next)
{
	Int i;
	obj_node* new;

	new = (obj_node*) CLG_MALLOC("fn.newnd.1", sizeof(obj_node));
	new->name  = di ? VG_(strdup)("fn.newnd.2", VG_(DebugInfo_get_filename)(di) )
			: anonymous_obj;
	for (i = 0; i < N_FILE_ENTRIES; i++) {
		new->files[i] = NULL;
	}
	CLG_(stat).distinct_objs ++;
	new->number  = CLG_(stat).distinct_objs;
	new->start   = di ? VG_(DebugInfo_get_text_avma)(di) : 0;
	new->size    = di ? VG_(DebugInfo_get_text_size)(di) : 0;
	new->offset  = di ? VG_(DebugInfo_get_text_bias)(di) : 0;
	new->next    = next;

	CLG_DEBUG(3,"new_obj_node: name %s number %d start 0x%lx offset 0x%lx size 0x%lx\n",
		  new->name,new->number,new->start,new->offset,new->size);

	// not only used for debug output (see static.c)
	new->last_slash_pos = 0;
	i = 0;
	while(new->name[i]) {
		if (new->name[i]=='/') new->last_slash_pos = i+1;
		i++;
	}

	if (runtime_resolve_addr == 0) search_runtime_resolve(new);

	if ( CLG_(clo).dump_loadmap ) record_obj_info(new);

	return new;
}

obj_node* CLG_(get_obj_node)(DebugInfo* di)
		{
	obj_node*    curr_obj_node;
	UInt         objname_hash;
	const HChar* obj_name;

	obj_name = di ? VG_(DebugInfo_get_filename)(di) : anonymous_obj;

	/* lookup in obj hash */
	objname_hash = str_hash(obj_name, N_OBJ_ENTRIES);
	curr_obj_node = obj_table[objname_hash];
	while (NULL != curr_obj_node &&
			VG_(strcmp)(obj_name, curr_obj_node->name) != 0) {
		curr_obj_node = curr_obj_node->next;
	}
	if (NULL == curr_obj_node) {
		obj_table[objname_hash] = curr_obj_node =
				new_obj_node(di, obj_table[objname_hash]);
	}

	return curr_obj_node;
		}


static __inline__ 
file_node* new_file_node(const HChar *filename,
		obj_node* obj, file_node* next)
{
   Int i;
   file_node* new = (file_node*) CLG_MALLOC("fn.newfilenode.1", sizeof(file_node));
   new->name  = VG_(strdup)("fn.newfilenode.2", filename);
   for (i = 0; i < N_FN_ENTRIES; i++) {
      new->fns[i] = NULL;
   }
   CLG_(stat).distinct_files++;
   new->number  = CLG_(stat).distinct_files;
   new->obj     = obj;
   new->next      = next;
   return new;
}

file_node* CLG_(get_file_node)(obj_node* curr_obj_node,
         const HChar *dir, const HChar *file)
{
   file_node* curr_file_node;
   UInt       filename_hash;

   CLG_DEBUG(6,"In get_file_node\n");

    /* Build up an absolute pathname, if there is a directory available */
   HChar filename[VG_(strlen)(dir) + 1 + VG_(strlen)(file) + 1];
   VG_(strcpy)(filename, dir);
   if (filename[0] != '\0') {
      VG_(strcat)(filename, "/");
   }
   VG_(strcat)(filename, file);

   /* lookup in file hash */
   filename_hash = str_hash(filename, N_FILE_ENTRIES);
   curr_file_node = curr_obj_node->files[filename_hash];
   while (NULL != curr_file_node &&
            VG_(strcmp)(filename, curr_file_node->name) != 0) {
      curr_file_node = curr_file_node->next;
   }
   if (NULL == curr_file_node) {
      curr_obj_node->files[filename_hash] = curr_file_node =
               new_file_node(filename, curr_obj_node,
                             curr_obj_node->files[filename_hash]);
   }

   return curr_file_node;
}

/* forward decl. */
static void resize_fn_array(void);

static __inline__ 
fn_node* new_fn_node(const HChar *fnname,
		file_node* file, fn_node* next)
{
   fn_node* new = (fn_node*) CLG_MALLOC("fn.newfnnode.1", sizeof(fn_node));
   new->name = VG_(strdup)("fn.newfnnode.2", fnname);

   CLG_(stat).distinct_fns++;
   new->number   = CLG_(stat).distinct_fns;
   new->last_cxt = 0;
   new->pure_cxt = 0;
   new->file     = file;
   new->next     = next;
   new->skip         = False;
   new->paused    = False;
   new->caller_paused = False;
   new->pop_on_jump  = CLG_(clo).pop_on_jump;
   new->group        = 0;
#if CLG_ENABLE_DEBUG
   new->verbosity    = -1;
#endif
   new->separate_callers    = 0;
   new->separate_recursions = 2;

   if (CLG_(stat).distinct_fns >= current_fn_active.size)
      resize_fn_array();
   new->trace = Lk_TrxtNone;

   return new;
}


/* Get a function node in hash2 with known file node.
 * hash nodes are created if needed
 */
static
fn_node* get_fn_node_infile(file_node* curr_file_node,
		const HChar *fnname)
{
   fn_node* curr_fn_node;
   UInt     fnname_hash;

   CLG_ASSERT(curr_file_node != 0);

   /* lookup in function hash */
   fnname_hash = str_hash(fnname, N_FN_ENTRIES);
   curr_fn_node = curr_file_node->fns[fnname_hash];
   while (NULL != curr_fn_node &&
            VG_(strcmp)(fnname, curr_fn_node->name) != 0) {
      curr_fn_node = curr_fn_node->next;
   }
   if (NULL == curr_fn_node) {
      curr_file_node->fns[fnname_hash] = curr_fn_node =
               new_fn_node(fnname, curr_file_node,
                           curr_file_node->fns[fnname_hash]);
   }

   return curr_fn_node;
}


/* Get a function node in a Segment.
 * Hash nodes are created if needed.
 */
static __inline__
fn_node* get_fn_node_inseg(DebugInfo* di,
		const HChar *dirname,
		const HChar *filename,
		const HChar *fnname)
{
   obj_node  *obj  = CLG_(get_obj_node)(di);
   file_node *file = CLG_(get_file_node)(obj, dirname, filename);
   fn_node   *fn   = get_fn_node_infile(file, fnname);

   return fn;
}

Bool CLG_(get_debug_info)(Addr instr_addr,
         const HChar **dirname,
         const HChar **filename,
         const HChar **fn_name, UInt* line_num,
         DebugInfo** pSegInfo)
{
   Bool found_file_line, found_fn, result = True;
   UInt line;

   CLG_DEBUG(6, "  + get_debug_info(%p)\n", (void *)instr_addr);

   if (pSegInfo) {
      *pSegInfo = VG_(find_DebugInfo)(instr_addr);

      // for generated code in anonymous space, pSegInfo is 0
   }

   found_file_line = VG_(get_filename_linenum)(instr_addr,
            filename, dirname, &line);
   found_fn = VG_(get_fnname)(instr_addr, fn_name );

   if (!found_file_line && !found_fn) {
      CLG_(stat).no_debug_BBs++;
        *filename = "???";
        *fn_name = "???";
      if (line_num) *line_num=0;
      result = False;

   } else if ( found_file_line &&  found_fn) {
      CLG_(stat).full_debug_BBs++;
      if (line_num) *line_num=line;

   } else if ( found_file_line && !found_fn) {
      CLG_(stat).file_line_debug_BBs++;
      *fn_name = "???";
      if (line_num) *line_num=line;

   } else  /*(!found_file_line &&  found_fn)*/ {
      CLG_(stat).fn_name_debug_BBs++;
      *filename = "???";
      if (line_num) *line_num=0;
   }

   CLG_DEBUG(6, "  - get_debug_info(%p): seg '%s', fn %s\n",
             (void *)instr_addr,
             !pSegInfo   ? "-" :
                         (*pSegInfo) ? VG_(DebugInfo_get_filename)(*pSegInfo) :
                                     "(None)",
                                     *fn_name);

   return result;
}

/* for _libc_freeres_wrapper => _exit renaming */
static BB* exit_bb = 0;


/*
 * Attach function struct to a BB from debug info.
 */
fn_node* CLG_(get_fn_node)(BB* bb)
{
   const HChar      *dirname;
   const HChar      *filename;
   const HChar      *fnname;
   DebugInfo* di;
   UInt       line_num;
   fn_node*   fn;
   static HChar buf[99];

   /* fn from debug info is idempotent for a BB */
   if (bb->fn) return bb->fn;

   CLG_DEBUG(3,"+ get_fn_node(BB %p)\n", (void *)bb_addr(bb));

   /* get function/file name, line number and object of
    * the BB according to debug information
    */
   CLG_(get_debug_info)(bb_addr(bb),
            &dirname, &filename, &fnname, &line_num, &di);

   if (0 == VG_(strcmp)(fnname, "???")) {
      int p;

      /* Use address as found in library */
      if (sizeof(Addr) == 4)
         p = VG_(sprintf)(buf, "%8p", (void *)bb->offset);
      else
         // 64bit address
         p = VG_(sprintf)(buf, "%16p", (void *)bb->offset);

      VG_(sprintf)(((HChar *)buf+p), "%s",
               (bb->sect_kind == Vg_SectData) ? " [Data]" :
               (bb->sect_kind == Vg_SectBSS)  ? " [BSS]"  :
               (bb->sect_kind == Vg_SectGOT)  ? " [GOT]"  :
               (bb->sect_kind == Vg_SectPLT)  ? " [PLT]"  : "");
      fnname = buf;
   }
   else {
      if (VG_(get_fnname_if_entry)(bb_addr(bb), &fnname))
         bb->is_entry = 1;
   }

   /* HACK for correct _exit:
    * _exit is redirected to VG_(__libc_freeres_wrapper) by valgrind,
    * so we rename it back again :-)
    */
   if (0 == VG_(strcmp)(fnname, "vgPlain___libc_freeres_wrapper")
            && exit_bb) {
      CLG_(get_debug_info)(bb_addr(exit_bb),
               &dirname, &filename, &fnname, &line_num, &di);

      CLG_DEBUG(1, "__libc_freeres_wrapper renamed to _exit\n");
   }
   if (0 == VG_(strcmp)(fnname, "_exit") && !exit_bb)
      exit_bb = bb;

   if (runtime_resolve_addr &&
            (bb_addr(bb) >= runtime_resolve_addr) &&
            (bb_addr(bb) < runtime_resolve_addr + runtime_resolve_length)) {
      /* BB in runtime_resolve found by code check; use this name */
      VG_(sprintf)(buf, "_dl_runtime_resolve");
      fnname = buf;
   }

   /* get fn_node struct for this function */
   fn = get_fn_node_inseg( di, dirname, filename, fnname);

   /* if this is the 1st time the function is seen,
    * some attributes are set */
   if (fn->pure_cxt == 0) {

      /* Every function gets a "pure" context, i.e. a context with stack
       * depth 1 only with this function. This is for compression of mangled
       * names
       */
      fn_node* pure[2];
      pure[0] = 0;
      pure[1] = fn;
      fn->pure_cxt = CLG_(get_cxt)(pure+1);

      if (bb->sect_kind == Vg_SectPLT)
         fn->skip = CLG_(clo).skip_plt;

      if (VG_(strcmp)(fn->name, "_dl_runtime_resolve")==0) {
         fn->pop_on_jump = True;

         if (VG_(clo_verbosity) > 1)
            VG_(message)(Vg_DebugMsg, "Symbol match: found runtime_resolve: %s +%p=%p",
                     bb->obj->name + bb->obj->last_slash_pos,
                     (void *)bb->offset, (void *)bb_addr(bb));
      }

      /* apply config options from function name patterns
       * given on command line */
      CLG_(update_fn_config)(fn);
   }


   bb->fn   = fn;
   bb->line = line_num;

    if (dirname[0]) {
       CLG_DEBUG(3,"- get_fn_node(BB %#lx): %s (in %s:%u)\n",
                 bb_addr(bb), fnname, filename, line_num);
    } else
       CLG_DEBUG(3,"- get_fn_node(BB %#lx): %s (in %s/%s:%u)\n",
                 bb_addr(bb), fnname, dirname, filename, line_num);

   return fn;
}


/*------------------------------------------------------------*/
/*--- Active function array operations                     ---*/
/*------------------------------------------------------------*/

/* The active function array is a thread-specific array
 * of UInts, mapping function numbers to the active count of
 * functions.
 * The active count is the number of times a function appears
 * in the current call stack, and is used when costs for recursion
 * levels should be separated.
 */

UInt* CLG_(get_fn_entry)(Int n)
{
   CLG_ASSERT(n < current_fn_active.size);
   return current_fn_active.array + n;
}

void CLG_(init_fn_array)(fn_array* a)
{
   Int i;

   CLG_ASSERT(a != 0);

   a->size = N_INITIAL_FN_ARRAY_SIZE;
   if (a->size <= CLG_(stat).distinct_fns)
      a->size = CLG_(stat).distinct_fns+1;
   a->array = (UInt*) CLG_MALLOC("fn.initfnarray", a->size * sizeof(UInt));
   for(i=0;i<a->size;i++)
      a->array[i] = 0;
}

void CLG_(copy_current_fn_array)(fn_array* dst)
{
   CLG_ASSERT(dst != 0);

   dst->size  = current_fn_active.size;
   dst->array = current_fn_active.array;
}

fn_array* CLG_(get_current_fn_array)()
{
   return &current_fn_active;
}

void CLG_(set_current_fn_array)(fn_array* a)
{
   CLG_ASSERT(a != 0);

   current_fn_active.size  = a->size;
   current_fn_active.array = a->array;
   if (current_fn_active.size <= CLG_(stat).distinct_fns)
      resize_fn_array();
}

/* ensure that active_array is big enough:
 *  <distinct_fns> is the highest index, so <fn_active_array_size>
 *  has to be bigger than that.
 */
static void resize_fn_array(void)
{
	UInt* new;
	Int i, newsize;

	newsize = current_fn_active.size;
	while (newsize <= CLG_(stat).distinct_fns) newsize *=2;

	CLG_DEBUG(0, "Resize fn_active_array: %d => %d\n",
			current_fn_active.size, newsize);
	new = (UInt*) CLG_MALLOC("fn.resizefnarray", newsize * sizeof(UInt));
	for(i=0;i<current_fn_active.size;i++)
		new[i] = current_fn_active.array[i];
	while(i<newsize)
		new[i++] = 0;

	VG_(free)(current_fn_active.array);
	current_fn_active.size = newsize;
	current_fn_active.array = new;
	CLG_(stat).fn_array_resizes++;
}


