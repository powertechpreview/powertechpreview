# Simple code for valgrind.

.data
	stack: .string "abcdefghijk\n"
	len = . -stack
.text
.global _start

_start:
	movl $len, %edx
	movl $stack, %ecx

	# self increasment
	movl $stack, %ecx
	incl (%ecx)

	# push stack
	movl $stack, %eax
	addl $4, %eax
	movb  $'x', (%eax) 
	pushl (%eax)

	movl $1, %ebx
	movl $4, %eax
	nop
	int $0x80

	movl $0, %ebx
	movl $1, %eax
	int $0x80
