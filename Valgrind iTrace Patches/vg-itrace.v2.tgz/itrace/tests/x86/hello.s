#
# Simple code for valgrind.

.data
	msg: .string "Hello Word!\n"
	len = . -msg
.text
.global _start

_start:
	movl $len, %edx
	movl $msg, %ecx

	movl $msg, %ecx
	movb  $'a', (%ecx)

	movl $1, %ebx
	movl $4, %eax
	nop
	int $0x80

	testl %eax, %eax
	js 1f
	nop
1:
	movl $0, %ebx
	movl $1, %eax
	int $0x80
