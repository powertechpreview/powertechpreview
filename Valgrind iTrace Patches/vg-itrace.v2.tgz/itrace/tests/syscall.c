#include <fcntl.h>
#include <unistd.h>
int main ()
{
   int fd;
   fd = open ("itrace/tests/ppc32/syscall.c",O_RDONLY);
   close (fd);
   return 0;
}
