.data                       # section declaration - variables only

msg:
	.string "Hello, world!\n"
	len = . - msg       # length of our dear string

.text                       # section declaration - begin code

	.global _start
_start:

# write our string to stdout

#	lis	4,msg@l(5)
	lis     4,msg@ha    # load top 16 bits of &msg
	addi    4,4,msg@l   # load bottom 16 bits
	li      5,len       # third argument: message length
	nop

	lwz	10,4(4)	    # Load

	li	10,'a'	    # Rewrite msg
	stb	10,4(4)
	
	lwz	10,4(4)	    # Load again after write

	# loop test
	li	10,3
1:
	subi	10,10,1
	cmpi	0,10,1
	bne	1b	

	li      0,4         # syscall number (sys_write)
	li      3,1         # first argument: file descriptor (stdout)
	                    # second argument: pointer to message to write
	sc                  # call kernel

# and exit

	li      0,1         # syscall number (sys_exit)
	li      3,1         # first argument: exit code
	sc                  # call kernel
