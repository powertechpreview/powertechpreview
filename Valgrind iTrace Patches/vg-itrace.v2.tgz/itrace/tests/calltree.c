/* Test case for valgrind-option --trace-calltree.
   This file is written by Yao Qi <qiyao@cn.ibm.com>.
*/
#include<stdio.h>
void foo()
{
   int a;
   a = 0;
   a = a+1;
}

int f(int i)
{
   if (i > 1)
      return i * f(i-1);
   else {
      foo();
      return 1;
  }
}

int main ()
{
   int n;
   n = f(3);
   printf("%d\n",n);
   return 0;
}
