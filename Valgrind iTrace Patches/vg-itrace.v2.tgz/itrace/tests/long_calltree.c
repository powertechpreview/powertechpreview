/* Test case for valgrind-option --function-trigger
*/
#include <stdio.h>

int __attribute__ ((noinline)) function_four(int x)
{
   return x+1;
}

int function_three(int x)
{
   int i;
   for (i=0;i<8;i++) x+=0x100;
   return function_four(x);
}

int function_two(int x)
{
   int i;
   for (i=0;i<4;i++) x+=0x1000;
   x=function_four(x);
   for (i=0;i<4;i++) x+=0x10000;
   return function_three(x);
}

int function_one(int x)
{
   int i;
   for (i=0;i<8;i++) x+=0x1000000;
   return function_two(x);
}

int main ()
{
   long x;
   x=0;
   x=function_one(x);
//   printf("x:%lx\n",x);
   return 0;
}
