# Target numbers are based on results measured on a power7 fedora 18 environment.
# measured as ?.
TARGET_I_COUNT=1000
# measured as ~314.
TARGET_J_COUNT=200
# measured as ~17.
TARGET_JUMP_COUNT=10
# measured as ~472.
TARGET_READ_COUNT=200
# measured as ~190.
TARGET_WRITE_COUNT=100
