vgi2qt -- a conversion tool to convert valgrind itrace output to qtrace instruction traces

Uttam Pawar
IBM Beaverton
01/25/2006
pawar@us.ibm.com

CONTENTS
--------
vgi2qt.C    - source code of the tool
vgi2qt      - an executable
README.vgi2qt - this README file

Run time dependencies :
-------------
None.

Compile time dependencies (these are part of qtrace_starter kit package):
-------------------------------------------------------------------------
Headers :
qt.h 


Other tools needed (optional):
------------------------------
- sim_ppc package - a tool to see qtrace output in graphical form (java based)
- dump_qtrace - a program to get the dump of .qt file in ascii format.


Following is the list of affected fields from qtrace format:
QTRACE Header record:
--------------------
magic 
version
iar
comment_length
comment

QTRACE record:
-------------
Record number
offset
iar
instr
iar_change_present
node_present
termination_present
data_address_present
instruction_address_present


Limitations:
------------
Currently 'G' records (which indicates gap in the trace) are ignored from the output qtrace format.


