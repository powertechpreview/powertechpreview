/* File vgi2qt.c created by Uttam C. Pawar on Thu Jan 19 2006.
   Copyright IBM Corp 2006
   Refer to copyright instructions form no. G120-2083
*/

#include <stdio.h>
#include <stdint.h>

/* qtrace format code adapted from IBM's Performance Inspector project */
#define QTRACE_REC_BRANCH         0x01  
#define QTRACE_REC_UNTAKEN_BRANCH 0x02  
#define QTRACE_REC_LOAD_STORE     0x04  
#define QTRACE_REC_LENGTH         0x08  
#define QTRACE_REC_DATA_VSID      0x10  
#define QTRACE_ExceededMaximumBranchDepth      0x80 /* cwc */

typedef struct _qtrace_rec {
   unsigned int instruction;
   unsigned char node;
   unsigned char termination_node;
   uint64_t data_ea;
   uint64_t data_vsid;  // actual VSID length is 50 bits for 64-bit EAs
   unsigned int length;
   uint64_t instruction_ea;

   unsigned int flags;
} qtrace_rec;

int qtlib_record(qtrace_rec *rec, int outfile);
int qtlib_header(uint64_t addr, const char *comment, int outfile);
void qtlib_flush(int fd);
