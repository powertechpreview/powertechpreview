#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include "qt.h"

/* qtrace format code adapted from IBM's Performance Inspector project */
unsigned short flags_for_rec(qtrace_rec *);

#if __BYTE_ORDER__ == __ORDER_LITTLE_ENDIAN__
#define cpu_to_be16(A)	__builtin_bswap16(A)
#define cpu_to_be32(A)	__builtin_bswap32(A)
#define cpu_to_be64(A)	__builtin_bswap64(A)
#else
#define cpu_to_be16(A)	(A)
#define cpu_to_be32(A)	(A)
#define cpu_to_be64(A)	(A)
#endif

#define QTLIB_BUFSIZE 16*1024*1024
static unsigned char rbuf[QTLIB_BUFSIZE];
static unsigned long bufix=0;

/* for flushing the buffer when we are done writing all the output */
void qtlib_flush(int fd)
{
    if ( bufix > 0 ) {
	ssize_t rv = write(fd,rbuf,bufix);
	if ( rv != ssize_t(bufix) ) {
	    perror("write failed in qtlib_flush");
	    exit(1);
	}
	bufix=0;
    }
    return;
}

/* place output from qtlib_header/qtlib_record into buffer, flush when full. */
static inline void QTWRITE(const void *vp, unsigned long sz, int fd)
{
    ssize_t wrv;
    unsigned char *p = (unsigned char *)vp;
    if((bufix+(sz))>=(QTLIB_BUFSIZE)) {
	/* exactly fill the buffer for max i/o perf assuming power of 2 device block sizes */
	unsigned long remainder = (bufix+sz)-(QTLIB_BUFSIZE);
	unsigned long part1 = sz-remainder;
	memcpy(rbuf+bufix,p,part1);
	bufix += part1;
	p += part1;
	sz=remainder;
	wrv = write(fd,rbuf,bufix);
	if ( wrv != ssize_t(bufix) ) {
	    perror("qt write failed");
	    exit(1);
	}
	bufix=0;
	if ( sz == 0 ) return;
    }

    memcpy(rbuf+bufix,p,sz);
    bufix += (sz);
}


int qtlib_header(uint64_t addr, const char *comment, int outfile)
{
	uint64_t ul;
	unsigned int ui;
	unsigned short us, us_save;

	/* beginning */
	ul = 0x00010002;
	ul = cpu_to_be64(ul);
	QTWRITE(&ul, sizeof(uint64_t), outfile);

	/* iar_present, version_number_present, magic_number_present */
	us = 0xe002;
	us = cpu_to_be16(us);
	QTWRITE(&us, sizeof(unsigned short), outfile);

	/* magic */
	ui = 0;
	ui = cpu_to_be32(ui);
	QTWRITE(&ui, sizeof(uint32_t), outfile);

	/* version */
	ui = 0x01040700;
	ui = cpu_to_be32(ui);
	QTWRITE(&ui, sizeof(uint32_t), outfile);

	/* iar */
	ul = addr;
	ul = cpu_to_be64(ul);
	QTWRITE(&ul, sizeof(uint64_t), outfile);

	/* comment length */
	us = strlen(comment);
	us_save = us;
	us = cpu_to_be16(us);
	QTWRITE(&us, sizeof(unsigned short), outfile);

	/* comment */
	QTWRITE(comment, us_save, outfile);
	return 0;
}

int qtlib_record(qtrace_rec *rec, int outfile)
{
	uint64_t ul;
	unsigned int ui;
	unsigned short us;
	unsigned char ub;

	/* instruction */
	ui = rec->instruction;
	ui = cpu_to_be32(ui);


	QTWRITE(&ui, sizeof(uint32_t), outfile);

	/* flags? cwc */
	us = flags_for_rec(rec);
	us = cpu_to_be16(us);
	QTWRITE(&us, sizeof(unsigned short), outfile);

	if (rec->flags & QTRACE_REC_BRANCH) {
		ub = 0; /* node */
		QTWRITE(&ub, sizeof(unsigned char), outfile);
		us = QTRACE_ExceededMaximumBranchDepth; /* termination_code */
		us = cpu_to_be16(us);
		QTWRITE(&us, sizeof(unsigned short), outfile);
	}
	if (rec->flags & QTRACE_REC_LOAD_STORE) {
		ul = rec->data_ea;
		ul = cpu_to_be64(ul);
		QTWRITE(&ul, sizeof(uint64_t), outfile);
	}
	if (rec->flags & QTRACE_REC_DATA_VSID) {
		ul = *((uint64_t *) &rec->data_vsid);
		ul = cpu_to_be64(ul);
		QTWRITE(&ul, 7, outfile); /* cwc len? */
	}
	if (rec->flags & QTRACE_REC_LENGTH) {
		ub = rec->length;
		QTWRITE(&ub, sizeof(unsigned char), outfile);
	}
	if ((rec->flags & QTRACE_REC_BRANCH) &&
		!(rec->flags & QTRACE_REC_UNTAKEN_BRANCH)) {
		ul = rec->instruction_ea;
		ul = cpu_to_be64(ul);
		QTWRITE(&ul, sizeof(uint64_t), outfile);
	}

	return 0;
}

unsigned short flags_for_rec(qtrace_rec *rec)
{
	unsigned short rv = 0;

	if (rec->flags & QTRACE_REC_BRANCH) {
		rv |= 0x6000; /* node_present(1) termination_present(2) */

		if (!(rec->flags & QTRACE_REC_UNTAKEN_BRANCH)) {
			/* iar_change_present(0) instruction_address_present(9) */
			rv |= 0x8040; 
		}
	}

	if (rec->flags & QTRACE_REC_LOAD_STORE) {
		rv |= 0x0800; /* data_address_present(4) */
		if (rec->flags & QTRACE_REC_DATA_VSID)
			rv |= 0x0400; /* data_vsid_present(5) */
		if (rec->flags & QTRACE_REC_LENGTH) {
			rv |= 0x0100; /* length_present(7) */
		}
	}
	return rv;
}
