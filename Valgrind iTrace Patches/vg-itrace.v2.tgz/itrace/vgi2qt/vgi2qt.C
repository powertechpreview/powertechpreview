/* File vgi2qt.c created by Uttam C. Pawar on Thu Jan 19 2006.
	Copyright IBM Corp 2006
*/

/* Change Activity: */
/* End Change Activity */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <errno.h>
#include <assert.h>
#include <sys/mman.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <getopt.h>
#include <stdint.h>
#define __STDC_FORMAT_MACROS
#include <inttypes.h>
#include "qt.h"

#define NORECORDS         -1
#define ADDR_STRING_LEN   19   // 17 chars needed for 64-bit addr + NULL; 2 more chars for "0x" at front of string
#define GENERATED_ADDR_STRING_LEN 17 //  Only 17 needed here, since our intToHexstr doesn't add "0x" to the front
#define INSTR_STRING_LEN  9
#define MAX_LENGTH        1024
#define MAX_COMMENT       1024
#define VGI2QT_VERSION    "1.0"

// NOTE: The following #define must be sync'ed with the same-named define in itrace.h
#define ITRACE_BIN_MAGIC_NUM 0x181a191b1d1c1e1fULL // Indicates binary input file in VGI format


enum bool_flags { FALSE, TRUE};

typedef struct _vgi_trace_record {
	char c_type;
	char s_addr[ADDR_STRING_LEN];
	char s_instr[INSTR_STRING_LEN];
	uint64_t i_addr;
	unsigned int i_instr;
	int valid;
} vgi_trace_record;

static int qt_file;
static int qt_header;
static uint64_t num_recs;
static int in_lines;
static char CurrHexAddr[ADDR_STRING_LEN];
static uint64_t CurrInstrAddr;
static char temp_str[GENERATED_ADDR_STRING_LEN];
static int debug_flag;

////////////////////////////

// Begin functions for processing text format file
static uint64_t hexStrToInt (char *str)
{
	uint64_t final_int = 0;
	char * endptr;
	final_int = strtoll(str, &endptr, 16);
	if ((endptr >= str) &&
			(endptr <= (str + strlen(str) - 1))) {
		fprintf(stderr, "Invalid numeric value in %s\n", str);
		final_int = ~0;
	}
	return final_int;
}

static char * IntToHexstr(uint64_t num)
{
	memset( temp_str, 0, sizeof(temp_str));
	snprintf(temp_str, sizeof(temp_str), "0x%llx", (unsigned long long)num);
	return temp_str;
}

static void command_options ( char *pname)
{
	printf("\n  %s [-h] | [-v] | --input-file input_file_name \n", pname);
	printf("\t| [--output-file output_filename]\n\n");

	printf("  Required Options:\n");
	printf("      -f / --input-file input_file_name\n");
	printf("             The input file containing the valgrind-itrace ");
	printf("formated file.\n\n");

	printf("  Optional Options:\n");
	printf("       -o / --output-file output_file_name\n");
	printf("              The user specified output file name.  If not ");
	printf("specified \n");
	printf("              it is set to \"output.qt\" by default\n");

	printf("       -v / --version\n");
	printf("              Print the version of %s and exit normally.\n",
	       pname);
	printf("       -h / --help\n");
	printf("              Print the command help message and exit.\n\n");
}

static void help ( char *pname)
{
	printf("\n");
	printf("  This program reads valgrind-itrace-format file from the ");
	printf("input file specified\n");
	printf("  with the -f option and creates a qtrace formated output ");
	printf("file that is\n");
	printf("  optionally specified using the -o option.\n");
	command_options(pname);
	exit(0);
}

static bool_flags isbranch (unsigned int instr)
{
	bool_flags return_flag;
	int opcode, extend;

	opcode = (instr >> 26) & 0x3f;

	if (opcode > 19) 
		return FALSE;

	if (opcode >= 16 && opcode <= 18)
		return TRUE; /* 16=bc, 17=sc/scv, 18=b */

	extend = (instr >> 1) & 0x3ff;

	return_flag = FALSE;
	if (opcode == 19) {
		if (extend == 16)  
			return_flag = TRUE; /* bclr */
		else 
			if (extend == 528) 
				return_flag = TRUE; /* bcclr */
		else 
			if (extend == 50)  
				return_flag = TRUE; /* rfi */
		else 
			if (extend == 82)  
				return_flag = TRUE; /* rfscv */
		else 
			if (extend == 18)  
				return_flag = TRUE; /* rfid */

		return (return_flag);
	}

	if (opcode == 0 && extend == 257)  
		return_flag = TRUE; /* bccbr */

	return return_flag;
}


static int getNextVgiTextRecord (vgi_trace_record *vgiPtr, int lookahead, FILE * fp_ptr)
{
	char buffer[MAX_LENGTH+1], *rec, *token; 
	int len, index;
	fpos_t pos;

	len=0;
	index=0;
	token=NULL;

	if (lookahead)
		fgetpos(fp_ptr, &pos);

	memset ((char *)buffer, '\0', MAX_LENGTH+1);
	memset ( vgiPtr, 0, sizeof (vgi_trace_record));
	while (1) {
		if (fgets (buffer, MAX_LENGTH, fp_ptr)) {
			in_lines++;
			len = strlen(buffer);
			for (index=0; index < len; index++)
					if (buffer[index] == '\n')
						buffer[index] = '\0';

		if (buffer[0] == '\0' || buffer[0] == '=' )
			continue;

		rec = buffer;

		token = strtok (rec, " ");
		if (token) {
			vgiPtr->c_type = *token;
			token = strtok (NULL, " ");
			if (token && *token != ' ' && 
				(vgiPtr->c_type == 'J' || vgiPtr->c_type == 'I' || 
				vgiPtr->c_type == 'R' || vgiPtr->c_type == 'W' ||
				vgiPtr->c_type == 'G')) {
				if (vgiPtr->c_type == 'G') {
					fprintf (stdout,
						 "Found G record at line [%d] in the input file\n",
							in_lines);
					continue;
				}

				if (vgiPtr->c_type == 'I') {
					CurrInstrAddr += 4;
					/* save addresses as a strings */
					strncpy (vgiPtr->s_addr,
						IntToHexstr (CurrInstrAddr),
						ADDR_STRING_LEN);
					strncpy (vgiPtr->s_instr, token, INSTR_STRING_LEN);
					vgiPtr->i_addr = CurrInstrAddr;

					/* save the instruction as u_int */
					vgiPtr->i_instr = hexStrToInt (token);

					/* save new address as current address */
					strncpy (CurrHexAddr, vgiPtr->s_addr,
						 ADDR_STRING_LEN);
					if (lookahead)
						CurrInstrAddr -= 4;
				} else {
						if (vgiPtr->c_type == 'J') {
							 strncpy (CurrHexAddr, token, ADDR_STRING_LEN);
							 CurrInstrAddr = hexStrToInt (CurrHexAddr);
						}

						/* It's J/R/W records */
						/* save the address as a string */
						strncpy (vgiPtr->s_addr, token, ADDR_STRING_LEN);
						/* save the address as u_int */
						vgiPtr->i_addr = hexStrToInt (token);
									 
						token = strtok (NULL, " ");
						if (token && *token != ' ') {
							/* save the instruction as a string */
							strncpy (vgiPtr->s_instr, token, INSTR_STRING_LEN);
							/* Save the token as u_int.  For 'J' records, the token
							 * is the instruction, which is an unsigned int.  For
							 * 'R' and 'W' records, the token may represent 64-bit
							 * data values; but since createQtraceRecord ends up ignoring
							 * such records, we don't care about the potential truncation.
							 */
							vgiPtr->i_instr = hexStrToInt (token);
						} else {
							fprintf (stderr,
								 "One of J/R/W record doesn't have associated byte dump (3rd colum) "
								" at line [%d] in the input file\n", in_lines);
							exit (1);
						}
					}
					vgiPtr->valid = 1;  /* mark this as valid record */
					break;
				}
			}
		} else
			return NORECORDS;
	}

	if (lookahead)
		fsetpos (fp_ptr, &pos);

	return 1;
}

static void createQtraceHeader (vgi_trace_record v)
{
	const char * comment = "Qtrace created from valgrind-itrace";

	qtlib_header (v.i_addr, comment, qt_file);
	return;
}

static void createQtraceRecordFromText (vgi_trace_record v, FILE * fp_ptr)
{
	int is_branch, is_ls, nb_br = 0;
	vgi_trace_record vgiNextRec;
	qtrace_rec Q;

	memset(&Q, 0, sizeof(qtrace_rec));

	/* If the current record is load/store, ignore it */
	if (v.c_type == 'W' || v.c_type == 'R')
		return;

	vgiNextRec.valid = 0;
	getNextVgiTextRecord (&vgiNextRec, 1, fp_ptr);

	/* Is the current instruction load/store, default FALSE */
	is_ls = FALSE;
	
	/* chech if this is branch instruction */
	is_branch = isbranch (v.i_instr);
 
	if ((is_branch == FALSE) && 
			(vgiNextRec.c_type == 'W' || vgiNextRec.c_type == 'R'))
		is_ls = TRUE;
 
	Q.instruction = v.i_instr;          /* Actual instruction */
 
	if (is_branch) {
		/*
		Q.header.control.node_present = 1;
		Q.node = 0;
		Q.header.control.termination_present = 1;
		Q.termination_node = 0;
		Q.termination_code = QTRACE_ExceededMaximumBranchDepth;
		*/
		Q.flags = QTRACE_REC_BRANCH;
		if (vgiNextRec.valid && (vgiNextRec.i_addr != (v.i_addr+4))) {
		    nb_br = 1;
		}

		if ((v.i_addr != 0) && nb_br) {
			/* Q.header.control.instruction_address_present = 1; */
			Q.instruction_ea = vgiNextRec.i_addr;
		} else
			Q.flags |= QTRACE_REC_UNTAKEN_BRANCH;

	} else if (is_ls) {
		Q.flags |= QTRACE_REC_LOAD_STORE;
		Q.data_ea = vgiNextRec.i_addr;
		if (nb_br > 0) {
			Q.flags |= QTRACE_REC_LENGTH;
			/*
			Q.header.control.length_present = 1;
			*/
			Q.length = nb_br;
		}
	}
   num_recs++;

	qtlib_record(&Q, qt_file);
}

static void DumpTheCgiRecord (vgi_trace_record v)
{
	static int num=0;

	num++;
	fprintf (stdout, "---------------------------------------\n");
	fprintf (stdout, "[%d] T->[%c] \n", num, v.c_type);
	fprintf (stdout, "A->[%s=%llx=%s] \n", v.s_addr, (unsigned long long)v.i_addr, IntToHexstr (v.i_addr));
	fprintf (stdout, "I->[%s=%x=%s] \n", v.s_instr, v.i_instr, IntToHexstr (v.i_instr));

	return;
}
static void _process_text_file(FILE * fp_ptr)
{
   int retCode;
   vgi_trace_record vgiNextRec;
   while ( !feof(fp_ptr)) {
      retCode = getNextVgiTextRecord (&vgiNextRec, 0, fp_ptr);
      if (retCode == 1) {
         if (debug_flag)
            DumpTheCgiRecord (vgiNextRec);

         if (!qt_header) {
                  createQtraceHeader(vgiNextRec);
                  qt_header = 1;
         }
         createQtraceRecordFromText(vgiNextRec, fp_ptr);
      }
   }

   qtlib_flush(qt_file);

   if (fp_ptr)
      fclose (fp_ptr);
}
// End functions for processing text format file
////////////////////////////


////////////////////////////
// Begin functions for processing binary format file

#if BITS_PER_LONG == 64
#define MMAP_WINDOW_SZ ULLONG_MAX
#else
#define MMAP_WINDOW_SZ (32 * 1024 * 1024ULL)
#endif

static size_t mmap_size;
size_t pg_sz;

enum VG_ItraceType {
   VG_BEGIN = 1,  // H : start of trace
   VG_JADDR,      // J aaaa xxxx [; symbol]
   VG_INSN,       // I xxxx
   VG_GAP,        // G : gap
   // Do not change the order of the following enums
   VG_READ,       // R aaaaaaaa rrrr
   VG_WRITE,      // W aaaaaaaa wwwwwwww
   VG_END
};

//   <<<<<<<<<<<<< ATTENTION <<<<<<<<<<<<<
// This struct must be kept in sync with the same struct defined in itrace/itrace.h.
typedef struct {
   uint32_t type;  // One of VG_ItraceType
   uint32_t insn;
   uint64_t addr;
} VG_Itrace_record_t;

#define vgi_rec_len sizeof(VG_Itrace_record_t)

struct mmap_info {
   uint64_t offset, file_data_offset, file_data_size, head, shift;
   char * buf;
   int traceFD;
};

static VG_Itrace_record_t * _get_binary_format_vgi_rec(struct mmap_info * info, bool lookahead);
static void createQtraceRecordFromBinary (vgi_trace_record * v, struct mmap_info * info);
static VG_Itrace_record_t lookahead_rec;
static int __mmap_trace_file(struct mmap_info * info)
{
   int mmap_prot  = PROT_READ;
   int mmap_flags = MAP_SHARED;

   info->buf = (char *) mmap(NULL, mmap_size, mmap_prot,
                            mmap_flags, info->traceFD, info->offset);
   if (info->buf == MAP_FAILED) {
      fprintf(stderr, "Error: mmap failed with errno:\n\t%s\n", strerror(errno));
      fprintf(stderr, "size: 0x%lx; prot: 0x%x; flags: 0x%x; fd: %d; offset: 0x%lx\n", mmap_size,
              mmap_prot, mmap_flags, info->traceFD, info->offset);
      return -1;
   }
   return 0;
}


static int _it_mmap_trace_file(struct mmap_info * info, bool init)
{
   uint64_t shift;
   if (init) {
      if (!pg_sz)
         pg_sz = sysconf(_SC_PAGESIZE);
      if (!mmap_size) {
         if (MMAP_WINDOW_SZ > info->file_data_size) {
            mmap_size = info->file_data_size;
         } else {
            mmap_size = MMAP_WINDOW_SZ;
         }
      }
      info->offset = 0;
      info->head = info->file_data_offset;
      shift = pg_sz * (info->head / pg_sz);
      info->offset += shift;
      info->head -= shift;
   }

   return __mmap_trace_file(info);
}

static int getNextVgiBinaryRecord (vgi_trace_record * vgi_rec, struct mmap_info * info,
                                   bool lookahead)
{
   VG_Itrace_record_t * rec;
   char itrace_type[] = { 'x', 'B', 'J', 'I', 'G', 'R', 'W' };

   vgi_rec->valid = 0;

again:
   rec = _get_binary_format_vgi_rec(info, lookahead);
   if ((rec == NULL) || (rec->type == VG_END)) {
      vgi_rec->c_type = 'E'; // 'E' for End
      return -1;
   }

   vgi_rec->c_type = itrace_type[rec->type];
   switch (rec->type) {
      case VG_BEGIN: // ignore
         break;
      case VG_INSN:
      case VG_READ:
      case VG_WRITE:
      case VG_JADDR:
         vgi_rec->valid = 1;
         /* Currently, VG_READ and VG_WRITE will be ignored in the
          * createQtraceRecordFromBinary function, so we just blindly
          * set i_instr = rec->insn knowing full well that this is
          * only appropriate for VG_INSN and VG_JADDR types.
          */
         vgi_rec->i_instr = rec->insn;
         vgi_rec->i_addr = rec->addr;
         if (!qt_header) {
            createQtraceHeader(*vgi_rec);
            qt_header = 1;
         }
         if (debug_flag) {
            if ((rec->type == VG_INSN) || (rec->type == VG_JADDR)) {
               strncpy(vgi_rec->s_addr,
                       IntToHexstr(vgi_rec->i_addr),
                       ADDR_STRING_LEN);
               strncpy(vgi_rec->s_instr, IntToHexstr(vgi_rec->i_instr), INSTR_STRING_LEN);
            }
         }
         break;
      case VG_GAP:
         /* Pass 'false' for lookahead argument below to force forward progress in reading
          * the input data so as to skip the gap record.  Then go back to 'again' label
          * to try again to get the next record.
          */
         if (lookahead) {
            (void) _get_binary_format_vgi_rec(info, false);
            goto again;
         }
         break;
      default:
         fprintf(stderr, "At record #%"PRIu64", Unexpected trace record type %u\n", num_recs, rec->type);
         break;
   }
   return 0;
}


static void createQtraceRecordFromBinary (vgi_trace_record * v, struct mmap_info * info)
{
   int is_branch, is_ls, nb_br = 0;
   vgi_trace_record vgiNextRec;
   qtrace_rec Q;

   memset(&Q, 0, sizeof(qtrace_rec));

   /* If the current record is load/store, ignore it */
   if (v->c_type == 'W' || v->c_type == 'R')
      return;

   memset(&vgiNextRec, 0, sizeof(vgiNextRec));
   (void) getNextVgiBinaryRecord (&vgiNextRec, info, true);

   /* Is the current instruction load/store, default FALSE */
   is_ls = FALSE;

   /* chech if this is branch instruction */
   is_branch = isbranch (v->i_instr);

   if ((is_branch == FALSE) &&
         (vgiNextRec.c_type == 'W' || vgiNextRec.c_type == 'R'))
      is_ls = TRUE;

   Q.instruction = v->i_instr;          /* Actual instruction */

   if (is_branch) {
      /*
      Q.header.control.node_present = 1;
      Q.node = 0;
      Q.header.control.termination_present = 1;
      Q.termination_node = 0;
      Q.termination_code = QTRACE_ExceededMaximumBranchDepth;
      */
      Q.flags = QTRACE_REC_BRANCH;
      if (vgiNextRec.valid && (vgiNextRec.i_addr != (v->i_addr+4))) {
	  nb_br = 1;
      }

      if ((v->i_addr != 0) && nb_br) {
         /* Q.header.control.instruction_address_present = 1; */
         Q.instruction_ea = vgiNextRec.i_addr;
      } else
         Q.flags |= QTRACE_REC_UNTAKEN_BRANCH;

   } else if (is_ls) {
      Q.flags |= QTRACE_REC_LOAD_STORE;
      Q.data_ea = vgiNextRec.i_addr;
      if (nb_br > 0) {
         Q.flags |= QTRACE_REC_LENGTH;
         /*
         Q.header.control.length_present = 1;
         */
         Q.length = nb_br;
      }
   }
   num_recs++;
   qtlib_record(&Q, qt_file);
}


static VG_Itrace_record_t * _get_binary_format_vgi_rec(struct mmap_info * info, bool lookahead)
{
   VG_Itrace_record_t * trace_rec;
   struct mmap_info save_info;
   bool remapped = false;

   memcpy(&save_info, info, sizeof(save_info));

   if (info->offset + info->head >= info->file_data_offset + info->file_data_size)
      return NULL;

   if (!pg_sz)
      pg_sz = sysconf(_SC_PAGESIZE);

try_again:
   trace_rec = (VG_Itrace_record_t *)(info->buf + info->head);

   if ((mmap_size != info->file_data_size) &&
         ((info->head + vgi_rec_len) > mmap_size)) {
      int ret;
      uint64_t shift = pg_sz * ((info->head)/ pg_sz);
      ret = munmap(info->buf, mmap_size);
      if (ret) {
         perror("munmap failed");
         return NULL;
      }

      info->offset += shift;
      info->head -= shift;
      if (_it_mmap_trace_file(info, false))
         return NULL;
      remapped = true;
      goto try_again;
   }

   info->head += vgi_rec_len;
   if (info->offset + info->head >= info->file_data_offset + info->file_data_size)
      return NULL;

   if (lookahead) {
      info->head = save_info.head;
      if (remapped) {
         lookahead_rec.type = trace_rec->type;
         lookahead_rec.addr = trace_rec->addr;
         lookahead_rec.insn = trace_rec->insn;
         trace_rec = &lookahead_rec;
         int ret = munmap(info->buf, mmap_size);
         if (ret) {
            perror("munmap failed");
            return NULL;
         }
         info->offset = save_info.offset;
         if (_it_mmap_trace_file(info, false))
            return NULL;
      }
   }

   return trace_rec;
}

static int _process_binary_file(char * input_fname)
{
   struct mmap_info info;
   struct stat buf;
   vgi_trace_record vgi_rec;
   int rc = 0;
   info.file_data_offset = 16;
   info.traceFD = open(input_fname, O_RDONLY);
   if (info.traceFD == -1) {
      perror("Error opening input file");
      rc = -1;
      goto out;
   }
   rc = fstat(info.traceFD, &buf);
   if (rc) {
      perror("Error on fstat of input file");
      goto out_close;
   }
   info.file_data_size = buf.st_size;
   rc = _it_mmap_trace_file(&info, true);
   if (rc)
      goto out_close;

  do {
     memset(&vgi_rec, 0, sizeof(vgi_rec));
     rc = getNextVgiBinaryRecord(&vgi_rec, &info, false);
     if (!rc) {
        if (debug_flag)
           DumpTheCgiRecord (vgi_rec);

        switch (vgi_rec.c_type) {
           case 'I':
           case 'J':
           case 'R':
           case 'W':
              createQtraceRecordFromBinary(&vgi_rec, &info);
              break;
           default:
              break;
        }
     }
   } while (!rc);

out_close:
   close(info.traceFD);
out:
   qtlib_flush(qt_file);
   return rc;
}

// End functions for processing binary format file
////////////////////////////

static struct option long_options [] = {
  { "input-file", required_argument, NULL, 'f'},
  { "output-file", required_argument, NULL, 'o'},
  { "debug", no_argument, NULL,'d'},
  { "version", no_argument, NULL,'v'},
  { "help", no_argument, NULL, 'h'},
  { NULL, 0, NULL, 0}
};
const char * short_options = "f:o:dvh";            

int main(int argc, char **argv)
{
	char *infile  = NULL;
	char const *outfile = "output.qt";
	char *progname = argv[0];
	FILE * fp_ptr = NULL;
	unsigned long long actual_bin_magic[2];
	unsigned long long expected_bin_magic[] = { ITRACE_BIN_MAGIC_NUM, ITRACE_BIN_MAGIC_NUM};
	int rc=0;
	infile = NULL;
	bool done = FALSE;

	fp_ptr = stdin;

        while (!done) {
		int option_idx = 0;
		int c = getopt_long(argc, argv, short_options,
				    long_options, &option_idx);
		switch (c) {
		case -1:
			done = TRUE;
			break;
		case '?':
			command_options (progname);
			exit(-1);
			break;
		case 'h':
			help (progname);
			break;
		case 'f':
			infile = optarg;
			break;
		case 'o':
			outfile = optarg;
			break;
		case 'd':
			debug_flag = 1;
			break;
		case 'v':
			printf("%s version: %s\n", progname, VGI2QT_VERSION);
			exit(0);
		default:
			fprintf (stdout, "Illegal options (-%s) ignoring\n",
				 *argv);
			fprintf (stdout, "Try -h option to see the usage\n");
			break;
		}
        }

	if (infile == NULL) {
		printf("The input file name must be specified using either ");
		printf("the -f or the --input-file \noption. Exiting.\n");
		exit(-1);
	} else {
		fp_ptr = fopen (infile, "r");
	}

	if (fp_ptr == NULL) {
		fprintf (stderr, "Unable to open input file \"%s\".  ",
			 infile);
		fprintf(stderr, "Exiting.\n");
		exit(-1);
	}

	if (outfile)
	    qt_file = open (outfile, O_WRONLY|O_CREAT|O_TRUNC,0666);

	if (rc) {
		fprintf (stderr, "Unable to open output file \"%s\".\n",
			 outfile);
		fprintf(stderr, "Exiting.\n");
		exit(-1);
	}

	rc = fread(actual_bin_magic, 8, 2, fp_ptr);
	if ((rc == 2) && (!memcmp(actual_bin_magic, expected_bin_magic, 16))) {
	   _process_binary_file(infile);
	   printf("Created %"PRIu64" qt records\n", num_recs);
	   goto done;
	} else {
	   /* Assume it's a text-formatted VGI file and try to process it.
	    * Unfortunately, there's no good, fool-proof way for us to verify
	    * it's a text-formatted VGI file.  All records are printed to stderr,
	    * and the user typically redirects stdout and stderr to a file, which
	    * is then passed to vgi2qt.  This unsynchronized mix of stderr from
	    * valgrind-itrace with stdout/stderr from the app under test can
	    * result in intermingled output.  So trying to pick out an exact
	    * magic string that would indicate this is a text-formatted VGI file
	    * would be error prone.
	    */
	   rewind(fp_ptr);
	   _process_text_file(fp_ptr);
	   if (!num_recs)
	      printf("No records found in input file %s.  Are you sure this is a VGI file?\n",
	             infile);
	   else
	      printf("Created %"PRIu64" qt records\n", num_recs);
	   goto done;
	}

	if (feof(fp_ptr)) {
	   fprintf(stderr, "ERROR: Input file %s is empty.\n", infile);
	   exit(1);
	} else if (ferror(fp_ptr)) {
	   perror("Error reading input file.");
	   exit(1);
	}

done:

	close (qt_file);

	return 0;
}

/* Change Log
<@log@>
Fri Jul 30 2010 by Maynard Johnson <maynardj@@us.ibm.com>
Made changes to support 64-bit addresses

Fri Jul 30 2010 by Maynard Johnson <maynardj@@us.ibm.com>
Fixed bug in current instruction address calculation

Mon Feb 6 2006 11:00:01 by Uttam C. Pawar
<reason><version><Made changes to accomodate the new valgrin-itrace format.>

Thu Jan 31 2006 11:00:01 by Uttam C. Pawar
<reason><version><Brief description and why change was made.>

Thu Jan 30 2006 11:00:01 by Uttam C. Pawar
<reason><version><Brief description and why change was made.>

Thu Jan 26 2006 11:00:01 by Uttam C. Pawar
<reason><version><Brief description and why change was made.>

Thu Jan 19 2006 10:00:01 by Uttam C. Pawar
<reason><version><Created a new file (first version)>

*/
