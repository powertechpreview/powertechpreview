/*
 * @file itrace.h
 * *
 * Created on: Sep 24, 2012
 * @author Maynard Johnson
 * (C) Copyright IBM Corp. 2012 - 2013
 *
 *  This file is part of itrace, a Valgrind tool for instruction tracing.

 This program is free software; you can redistribute it and/or
 modify it under the terms of the GNU General Public License as
 published by the Free Software Foundation; either version 2 of the
 License, or (at your option) any later version.

 This program is distributed in the hope that it will be useful, but
 WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with this program; if not, write to the Free Software
 Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA
 02111-1307, USA.

 The GNU General Public License is contained in the file COPYING.
 */

#ifndef ITRACE_H_
#define ITRACE_H_

/*------------------------------------------------------------*/
/*--- Instrumentation structures and event queue handling  ---*/
/*------------------------------------------------------------*/

/* Maintain an ordered list of memory events which are outstanding, in
 the sense that no IR has yet been generated to do the relevant
 helper calls.  The BB is scanned top to bottom and memory events
 are added to the end of the list, merging with the most recent
 notified event where possible (Dw immediately following Dr and
 having the same size and EA can be merged).

 This merging is done so that for architectures which have
 load-op-store instructions (x86, amd64), the insn is treated as if
 it makes just one memory reference (a modify), rather than two (a
 read followed by a write at the same address).

 At various points the list will need to be flushed, that is, IR
 generated from it.  That must happen before any possible exit from
 the block (the end, or an IRStmt_Exit).  Flushing also takes place
 when there is no space to add a new event.

 If we require the simulation statistics to be up to date with
 respect to possible memory exceptions, then the list would have to
 be flushed before each memory reference.  That would however lose
 performance by inhibiting event-merging during flushing.

 Flushing the list consists of walking it start to end and emitting
 instrumentation IR for each event, in the order in which they
 appear.  It may be possible to emit a single call for two adjacent
 events in order to reduce the number of helper function calls made.
 For example, it could well be profitable to handle two adjacent Ir
 events with a single helper call.  */


typedef enum {
   Ev_Ir, // Instruction read
   Ev_Dr, // Data read
   Ev_Dw, // Data write
   Ev_Dm, // Data modify (read then write)
   Ev_Bc, // branch conditional
   Ev_Bi, // branch indirect (to unknown destination)
   Ev_G
// Global bus event
} EventTag;

typedef IRExpr IRAtom;

typedef struct {
   EventTag tag;
   InstrInfo* inode;
   Bool is_entry;
   IREndness endian;
   union {
      struct {
      } Ir;
      struct {
         IRAtom* ea;
         Int szB;
      } Dr;
      struct {
         IRAtom* ea;
         Int szB;
      } Dw;
      struct {
         IRAtom* ea;
         Int szB;
      } Dm;
      struct {
         IRAtom* taken; /* :: Ity_I1 */
      } Bc;
      struct {
         IRAtom* dst;
      } Bi;
      struct {
      } G;
   } Ev;
} Event;

/* Up to this many unnotified events are allowed.  Number is
 arbitrary.  Larger numbers allow more event merging to occur, but
 potentially induce more spilling due to extending live ranges of
 address temporaries. */
#define N_EVENTS 16

/* A struct which holds all the running state during instrumentation.
 Mostly to avoid passing loads of parameters everywhere. */
typedef struct {
   /* The current outstanding-memory-event list. */
   Event events[N_EVENTS];
   Int events_used;

   /* The array of InstrInfo's is part of BB struct. */
   BB* bb;

   /* BB seen before (ie. re-instrumentation) */
   Bool seen_before;

   /* Number InstrInfo bins 'used' so far. */
   UInt ii_index;

   // current offset of guest instructions from BB start
   UInt instr_offset;

   /* The output SB being constructed. */
   IRSB* sbOut;
} ClgState;

#if defined(VG_BIGENDIAN)
# define CLGEndness Iend_BE
#elif defined(VG_LITTLEENDIAN)
# define CLGEndness Iend_LE
#else
# error "Unknown endianness"
#endif


InstrInfo* next_InstrInfo(ClgState* clgs, UInt instr_size);
void flushEvents_text_out(ClgState* clgs);
void flushEvents_binary_out(ClgState* clgs);
void addBBSetupCall(ClgState* clgs);
IRSB* itrace_text_instrument(VgCallbackClosure* closure, IRSB* sbIn,
                             const VexGuestLayout* layout, const VexGuestExtents* vge, IRType gWordTy,
                             IRType hWordTy);
IRSB* itrace_binary_instrument(VgCallbackClosure* closure, IRSB* sbIn,
                             const VexGuestLayout* layout, const VexGuestExtents* vge, IRType gWordTy,
                             IRType hWordTy);
void _itrace_begin_text(void);
void _itrace_begin_binary(void);
void _finish_text(void);
void _finish_binary(void);
void _print_usage(void);
void addEvent_Dw(ClgState* clgs, InstrInfo* inode, Int datasize, IRAtom* ea,
                 IREndness endian);
void addEvent_Dr(ClgState* clgs, InstrInfo* inode, Int datasize, IRAtom* ea,
                 IREndness endian);
void addEvent_Ir(ClgState* clgs, InstrInfo* inode);
void showEvent(Event* ev);
IRAtom* get_Event_dea(Event* ev);
Int get_Event_dszB(Event* ev);
void set_gap(void);

static inline void addConstMemStoreStmt(IRSB* bbOut, UWord addr, UInt val, IRType hWordTy) {
   addStmtToIRSB(bbOut, IRStmt_Store(CLGEndness, IRExpr_Const(hWordTy
         == Ity_I32 ? IRConst_U32(addr) : IRConst_U64(addr)), IRExpr_Const(
         IRConst_U32(val))));
}
Addr IRConst2Addr(IRConst* con);

/////////////////////////////////////
#define ITRACE_BIN_MAGIC_NUM 0x181a191b1d1c1e1fULL

#define ITRACE_HEADER_FILL 0xdeadbeefdeadbeefULL

// NOTE: The comments for each trace type refer to the text format
enum VG_ItraceType {
   VG_BEGIN = 1,  // H : start of trace
   VG_JADDR,      // J aaaaaaaa xxxx [; symbol] : Instruction (xxx), along with its address
   VG_INSN,       // I xxxx  : Instruction only
   VG_GAP,        // G : gap
   // Do not change the order of the following enums
   VG_READ,       // R aaaaaaaa rrrrrrrr  : Read data (rr..rr), along with its address
   VG_WRITE,      // W aaaaaaaa wwwwwwww  : Write data (w..ww), along with its address
   VG_END         // end of instruction trace
};

/*
 * For type VG_BEGIN, VG_END, VG_GAP, and VG_INSN, the addr field is not used,
 * although for VG_BEGIN, we do set it to ITRACE_HEADER_FILL.
 * This asymmetry in actual useful record data implies we still have room to
 * make some improvements in compacting the trace data.
 */
typedef struct {
   UInt type;  // One of VG_ItraceType
   UInt insn;
   ULong addr;
} VG_Itrace_record_t;

extern BBCC* bbcc;
extern Addr bb_base;
extern thread_info* ti;
extern Char* default_fnname;


#endif /* ITRACE_H_ */
